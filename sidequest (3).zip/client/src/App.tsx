import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Play from "./pages/Play";
import Leaderboard from "./pages/Leaderboard";
import Profile from "./pages/Profile";
import Friends from "./pages/Friends";
import Feed from "./pages/Feed";
import Nav from "./components/Nav";
import InstallPrompt from "./components/InstallPrompt";

function Router() {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: "oklch(97% 0.02 85)" }}>
      <Nav />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/play" component={Play} />
          <Route path="/leaderboard" component={Leaderboard} />
          <Route path="/profile/:id?" component={Profile} />
          <Route path="/friends" component={Friends} />
          <Route path="/feed" component={Feed} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
          <InstallPrompt />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
