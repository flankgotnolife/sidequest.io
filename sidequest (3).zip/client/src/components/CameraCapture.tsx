import { useState, useRef, useCallback, useEffect } from "react";
import { Camera, Video, X, SwitchCamera, Circle, Square, RotateCcw } from "lucide-react";

type CapturedMedia = {
  file: File;
  preview: string;
  mediaType: "photo" | "video";
};

type CameraCaptureProps = {
  onCapture: (media: CapturedMedia) => void;
  onClose: () => void;
  maxVideoSeconds?: number;
};

export default function CameraCapture({ onCapture, onClose, maxVideoSeconds = 120 }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [mode, setMode] = useState<"photo" | "video">("photo");
  const [facingMode, setFacingMode] = useState<"user" | "environment">("environment");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [cameraReady, setCameraReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ url: string; type: "photo" | "video" } | null>(null);

  // Start camera stream
  const startCamera = useCallback(async () => {
    try {
      // Stop existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: mode === "video",
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      setCameraReady(true);
      setError(null);
    } catch (err: any) {
      console.error("Camera error:", err);
      if (err.name === "NotAllowedError") {
        setError("Camera permission denied. Please allow camera access in your browser settings.");
      } else if (err.name === "NotFoundError") {
        setError("No camera found on this device.");
      } else {
        setError("Could not access camera. Please try again.");
      }
      setCameraReady(false);
    }
  }, [facingMode, mode]);

  // Initialize camera on mount
  useEffect(() => {
    startCamera();
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [startCamera]);

  // Take photo
  const takePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Mirror if front camera
    if (facingMode === "user") {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0);

    canvas.toBlob(
      (blob) => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        setPreview({ url, type: "photo" });
      },
      "image/jpeg",
      0.92
    );
  }, [facingMode]);

  // Start video recording
  const startRecording = useCallback(() => {
    if (!streamRef.current) return;

    chunksRef.current = [];

    // Try different MIME types for compatibility
    const mimeTypes = [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm",
      "video/mp4",
    ];

    let selectedMime = "";
    for (const mime of mimeTypes) {
      if (MediaRecorder.isTypeSupported(mime)) {
        selectedMime = mime;
        break;
      }
    }

    if (!selectedMime) {
      setError("Video recording is not supported in this browser.");
      return;
    }

    try {
      const recorder = new MediaRecorder(streamRef.current, {
        mimeType: selectedMime,
        videoBitsPerSecond: 5000000, // 5 Mbps
      });

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: selectedMime });
        const url = URL.createObjectURL(blob);
        setPreview({ url, type: "video" });
        setIsRecording(false);
        setRecordingTime(0);
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
      };

      recorder.start(1000); // Collect data every second
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordingTime(0);

      // Timer
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => {
          if (prev >= maxVideoSeconds - 1) {
            stopRecording();
            return prev;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (err) {
      console.error("Recording error:", err);
      setError("Failed to start recording.");
    }
  }, [maxVideoSeconds]);

  // Stop video recording
  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
  }, []);

  // Confirm captured media
  const confirmCapture = useCallback(() => {
    if (!preview) return;

    // Convert preview URL back to File
    fetch(preview.url)
      .then((r) => r.blob())
      .then((blob) => {
        const ext = preview.type === "photo" ? "jpg" : "webm";
        const mime = preview.type === "photo" ? "image/jpeg" : "video/webm";
        const file = new File([blob], `camera-${Date.now()}.${ext}`, { type: mime });
        onCapture({
          file,
          preview: preview.url,
          mediaType: preview.type,
        });
      });
  }, [preview, onCapture]);

  // Retake
  const retake = useCallback(() => {
    if (preview) {
      URL.revokeObjectURL(preview.url);
      setPreview(null);
    }
    startCamera();
  }, [preview, startCamera]);

  // Toggle camera
  const toggleCamera = useCallback(() => {
    setFacingMode((prev) => (prev === "user" ? "environment" : "user"));
  }, []);

  // Format recording time
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col"
      style={{ background: "oklch(15% 0.01 60)" }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3" style={{ background: "oklch(20% 0.01 60)" }}>
        <button
          onClick={onClose}
          className="p-2 cursor-pointer"
          style={{ color: "oklch(90% 0.02 80)" }}
        >
          <X size={24} />
        </button>

        <div className="flex gap-1">
          <button
            onClick={() => { if (!isRecording) setMode("photo"); }}
            className="px-4 py-1.5 text-sm font-bold cursor-pointer transition-all"
            style={{
              fontFamily: "'Permanent Marker', cursive",
              background: mode === "photo" ? "oklch(72% 0.15 50)" : "transparent",
              color: mode === "photo" ? "oklch(15% 0.02 60)" : "oklch(70% 0.02 80)",
              border: "1.5px solid oklch(50% 0.02 60)",
              borderRadius: "3px",
            }}
          >
            Photo
          </button>
          <button
            onClick={() => { if (!isRecording) setMode("video"); }}
            className="px-4 py-1.5 text-sm font-bold cursor-pointer transition-all"
            style={{
              fontFamily: "'Permanent Marker', cursive",
              background: mode === "video" ? "oklch(65% 0.18 25)" : "transparent",
              color: mode === "video" ? "oklch(15% 0.02 60)" : "oklch(70% 0.02 80)",
              border: "1.5px solid oklch(50% 0.02 60)",
              borderRadius: "3px",
            }}
          >
            Video
          </button>
        </div>

        <button
          onClick={toggleCamera}
          className="p-2 cursor-pointer"
          style={{ color: "oklch(90% 0.02 80)" }}
          disabled={isRecording}
        >
          <SwitchCamera size={24} />
        </button>
      </div>

      {/* Camera viewfinder / Preview */}
      <div className="flex-1 relative overflow-hidden flex items-center justify-center" style={{ background: "oklch(10% 0.01 60)" }}>
        {error && (
          <div className="text-center p-6">
            <Camera size={48} className="mx-auto mb-4" style={{ color: "oklch(60% 0.04 70)" }} />
            <p style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(75% 0.03 80)", fontSize: "0.9rem" }}>
              {error}
            </p>
            <button
              onClick={startCamera}
              className="mt-4 px-4 py-2 cursor-pointer"
              style={{
                fontFamily: "'Permanent Marker', cursive",
                background: "oklch(72% 0.15 50)",
                color: "oklch(15% 0.02 60)",
                border: "2px solid oklch(50% 0.02 60)",
                borderRadius: "3px",
              }}
            >
              Try Again
            </button>
          </div>
        )}

        {!error && !preview && (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
            style={{
              transform: facingMode === "user" ? "scaleX(-1)" : "none",
            }}
          />
        )}

        {preview && preview.type === "photo" && (
          <img src={preview.url} alt="Captured" className="w-full h-full object-contain" />
        )}

        {preview && preview.type === "video" && (
          <video
            src={preview.url}
            controls
            autoPlay
            playsInline
            className="w-full h-full object-contain"
          />
        )}

        {/* Recording indicator */}
        {isRecording && (
          <div
            className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-2"
            style={{
              background: "oklch(40% 0.2 25 / 0.9)",
              borderRadius: "20px",
            }}
          >
            <div
              className="w-3 h-3 rounded-full animate-pulse"
              style={{ background: "oklch(65% 0.25 25)" }}
            />
            <span
              style={{
                fontFamily: "'Courier Prime', monospace",
                color: "white",
                fontSize: "0.9rem",
                fontWeight: 700,
              }}
            >
              REC {formatTime(recordingTime)}
            </span>
          </div>
        )}
      </div>

      {/* Hidden canvas for photo capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Controls */}
      <div
        className="flex items-center justify-center gap-8 py-6 px-4"
        style={{ background: "oklch(20% 0.01 60)" }}
      >
        {!preview ? (
          <>
            {mode === "photo" ? (
              <button
                onClick={takePhoto}
                disabled={!cameraReady}
                className="rounded-full flex items-center justify-center cursor-pointer transition-all hover:scale-105 disabled:opacity-40"
                style={{
                  width: "72px",
                  height: "72px",
                  background: "oklch(95% 0.02 80)",
                  border: "4px solid oklch(72% 0.15 50)",
                  boxShadow: "0 0 0 3px oklch(30% 0.02 60)",
                }}
              >
                <Camera size={28} style={{ color: "oklch(30% 0.02 60)" }} />
              </button>
            ) : (
              <button
                onClick={isRecording ? stopRecording : startRecording}
                disabled={!cameraReady}
                className="rounded-full flex items-center justify-center cursor-pointer transition-all hover:scale-105 disabled:opacity-40"
                style={{
                  width: "72px",
                  height: "72px",
                  background: isRecording ? "oklch(55% 0.22 25)" : "oklch(65% 0.18 25)",
                  border: `4px solid ${isRecording ? "oklch(75% 0.15 25)" : "oklch(45% 0.12 25)"}`,
                  boxShadow: "0 0 0 3px oklch(30% 0.02 60)",
                }}
              >
                {isRecording ? (
                  <Square size={24} style={{ color: "white" }} />
                ) : (
                  <Circle size={28} style={{ color: "white", fill: "white" }} />
                )}
              </button>
            )}
          </>
        ) : (
          <div className="flex gap-4">
            <button
              onClick={retake}
              className="flex items-center gap-2 px-5 py-3 cursor-pointer transition-all hover:opacity-80"
              style={{
                fontFamily: "'Permanent Marker', cursive",
                background: "oklch(40% 0.03 60)",
                color: "oklch(90% 0.02 80)",
                border: "2px solid oklch(55% 0.03 60)",
                borderRadius: "4px",
                fontSize: "1rem",
              }}
            >
              <RotateCcw size={18} />
              Retake
            </button>
            <button
              onClick={confirmCapture}
              className="flex items-center gap-2 px-5 py-3 cursor-pointer transition-all hover:opacity-80"
              style={{
                fontFamily: "'Permanent Marker', cursive",
                background: "oklch(72% 0.15 50)",
                color: "oklch(15% 0.02 60)",
                border: "2px solid oklch(25% 0.02 60)",
                borderRadius: "4px",
                fontSize: "1rem",
              }}
            >
              <Camera size={18} />
              Use {preview.type === "photo" ? "Photo" : "Video"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
