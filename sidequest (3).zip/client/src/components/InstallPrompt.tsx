import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Download, X, Smartphone } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showBanner, setShowBanner] = useState(false);
  const [showIOSPrompt, setShowIOSPrompt] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Check if already dismissed
    const wasDismissed = localStorage.getItem("pwa-install-dismissed");
    if (wasDismissed) {
      const dismissedAt = parseInt(wasDismissed, 10);
      // Show again after 7 days
      if (Date.now() - dismissedAt < 7 * 24 * 60 * 60 * 1000) {
        setDismissed(true);
        return;
      }
    }

    // Check if already installed
    if (window.matchMedia("(display-mode: standalone)").matches) return;
    if ((navigator as any).standalone) return;

    // Android/Desktop install prompt
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setShowBanner(true);
    };
    window.addEventListener("beforeinstallprompt", handler);

    // iOS detection
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    const isSafari = /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent);
    if (isIOS && isSafari) {
      // Delay iOS prompt slightly
      setTimeout(() => setShowIOSPrompt(true), 3000);
    }

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setShowBanner(false);
    }
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setShowBanner(false);
    setShowIOSPrompt(false);
    setDismissed(true);
    localStorage.setItem("pwa-install-dismissed", Date.now().toString());
  };

  if (dismissed) return null;

  // Android/Desktop install banner
  if (showBanner) {
    return (
      <div className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md animate-in slide-in-from-bottom-4">
        <div className="sketch-card p-4 flex items-center gap-3 shadow-lg bg-[#FAF7F2]">
          <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-[#E8843C] flex items-center justify-center">
            <Download className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-heading text-lg text-[#3D3229] leading-tight">
              Install SideQuest
            </p>
            <p className="font-mono text-xs text-[#6B5B4E] mt-0.5">
              Add to home screen for the full app experience!
            </p>
          </div>
          <div className="flex flex-col gap-1.5 flex-shrink-0">
            <Button
              onClick={handleInstall}
              size="sm"
              className="bg-[#E8843C] hover:bg-[#D4732F] text-white font-heading text-sm border-2 border-[#3D3229] shadow-[2px_2px_0_#3D3229]"
            >
              Install
            </Button>
            <button
              onClick={handleDismiss}
              className="text-xs text-[#9C8B7A] hover:text-[#3D3229] font-mono"
            >
              Not now
            </button>
          </div>
        </div>
      </div>
    );
  }

  // iOS install instructions
  if (showIOSPrompt) {
    return (
      <div className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md animate-in slide-in-from-bottom-4">
        <div className="sketch-card p-4 shadow-lg bg-[#FAF7F2] relative">
          <button
            onClick={handleDismiss}
            className="absolute top-2 right-2 text-[#9C8B7A] hover:text-[#3D3229]"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-[#E8843C] flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-heading text-lg text-[#3D3229] leading-tight">
                Install SideQuest
              </p>
              <p className="font-mono text-xs text-[#6B5B4E] mt-1 leading-relaxed">
                Tap the{" "}
                <span className="inline-flex items-center">
                  <svg className="w-4 h-4 inline mx-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 12h16M12 4v16M8 8l4-4 4 4" />
                  </svg>
                </span>{" "}
                Share button, then scroll down and tap{" "}
                <strong>"Add to Home Screen"</strong>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
