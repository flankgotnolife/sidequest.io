import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";
import { Sword, Trophy, Users, Rss, User, LogIn, LogOut, Menu, X } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const navLinks = [
  { href: "/play", label: "Play", icon: Sword },
  { href: "/feed", label: "Feed", icon: Rss },
  { href: "/leaderboard", label: "Ranks", icon: Trophy },
  { href: "/friends", label: "Friends", icon: Users },
];

export default function Nav() {
  const { user, isAuthenticated } = useAuth();
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const logout = trpc.auth.logout.useMutation({
    onSuccess: () => {
      window.location.href = "/";
    },
    onError: () => toast.error("Logout failed"),
  });

  return (
    <nav
      className="sticky top-0 z-50"
      style={{
        background: "oklch(96% 0.025 80)",
        borderBottom: "2px solid oklch(25% 0.02 60)",
        boxShadow: "0 3px 0 oklch(25% 0.02 60)",
      }}
    >
      <div className="container">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 no-underline">
            <span
              className="text-2xl"
              style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}
            >
              SideQuest
            </span>
            <span className="text-xl">⚔️</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(({ href, label, icon: Icon }) => {
              const active = location === href || location.startsWith(href + "/");
              return (
                <Link
                  key={href}
                  href={href}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-sm transition-all no-underline"
                  style={{
                    fontFamily: "'Caveat', cursive",
                    fontWeight: 700,
                    fontSize: "1rem",
                    color: active ? "oklch(97% 0.02 85)" : "oklch(25% 0.02 60)",
                    background: active ? "oklch(25% 0.02 60)" : "transparent",
                    border: "2px solid oklch(25% 0.02 60)",
                    borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
                    boxShadow: active ? "2px 2px 0 oklch(15% 0.02 60)" : "none",
                  }}
                >
                  <Icon size={14} />
                  {label}
                </Link>
              );
            })}
          </div>

          {/* Auth */}
          <div className="hidden md:flex items-center gap-2">
            {isAuthenticated ? (
              <>
                <Link
                  href="/profile"
                  className="flex items-center gap-1.5 px-3 py-1.5 no-underline"
                  style={{
                    fontFamily: "'Caveat', cursive",
                    fontWeight: 700,
                    fontSize: "1rem",
                    color: "oklch(25% 0.02 60)",
                    border: "2px dashed oklch(40% 0.03 60)",
                    borderRadius: "3px 5px 4px 6px / 6px 4px 5px 3px",
                  }}
                >
                  <User size={14} />
                  {user?.name?.split(" ")[0] ?? "Me"}
                </Link>
                <button
                  onClick={() => logout.mutate()}
                  className="flex items-center gap-1.5 px-3 py-1.5 sketch-btn"
                  style={{
                    background: "oklch(80% 0.14 30)",
                    color: "oklch(20% 0.08 30)",
                    fontSize: "0.9rem",
                  }}
                >
                  <LogOut size={13} />
                  Out
                </button>
              </>
            ) : (
              <a
                href={getLoginUrl()}
                className="flex items-center gap-1.5 px-4 py-1.5 sketch-btn no-underline"
                style={{
                  background: "oklch(72% 0.15 50)",
                  color: "oklch(15% 0.02 60)",
                }}
              >
                <LogIn size={14} />
                Sign In
              </a>
            )}
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ color: "oklch(25% 0.02 60)" }}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div
            className="md:hidden pb-3 pt-1 flex flex-col gap-1"
            style={{ borderTop: "1px dashed oklch(60% 0.04 70)" }}
          >
            {navLinks.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2 px-3 py-2 no-underline"
                style={{
                  fontFamily: "'Caveat', cursive",
                  fontWeight: 700,
                  fontSize: "1.1rem",
                  color: "oklch(25% 0.02 60)",
                }}
              >
                <Icon size={16} />
                {label}
              </Link>
            ))}
            {isAuthenticated ? (
              <>
                <Link
                  href="/profile"
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2 px-3 py-2 no-underline"
                  style={{
                    fontFamily: "'Caveat', cursive",
                    fontWeight: 700,
                    fontSize: "1.1rem",
                    color: "oklch(25% 0.02 60)",
                  }}
                >
                  <User size={16} />
                  Profile
                </Link>
                <button
                  onClick={() => { logout.mutate(); setMenuOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2 text-left"
                  style={{
                    fontFamily: "'Caveat', cursive",
                    fontWeight: 700,
                    fontSize: "1.1rem",
                    color: "oklch(45% 0.15 25)",
                  }}
                >
                  <LogOut size={16} />
                  Sign Out
                </button>
              </>
            ) : (
              <a
                href={getLoginUrl()}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2 px-3 py-2 no-underline"
                style={{
                  fontFamily: "'Caveat', cursive",
                  fontWeight: 700,
                  fontSize: "1.1rem",
                  color: "oklch(25% 0.02 60)",
                }}
              >
                <LogIn size={16} />
                Sign In
              </a>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
