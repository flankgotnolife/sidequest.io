import { useState } from "react";
import { X, ChevronLeft, ChevronRight, Video, Image } from "lucide-react";

type MediaItem = {
  id: number;
  mediaUrl: string;
  mediaType: "photo" | "video";
  mimeType: string;
  order: number;
};

type MediaGalleryProps = {
  media: MediaItem[];
  initialIndex?: number;
};

/** Thumbnail grid with lightbox overlay */
export default function MediaGallery({ media, initialIndex }: MediaGalleryProps) {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(
    initialIndex !== undefined ? initialIndex : null
  );

  if (!media || media.length === 0) return null;

  const openLightbox = (idx: number) => setLightboxIndex(idx);
  const closeLightbox = () => setLightboxIndex(null);

  const goNext = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex + 1) % media.length);
  };
  const goPrev = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex - 1 + media.length) % media.length);
  };

  return (
    <>
      {/* Thumbnail grid */}
      <div className="flex flex-wrap gap-2">
        {media.map((m, idx) => (
          <button
            key={m.id}
            onClick={() => openLightbox(idx)}
            className="relative cursor-pointer overflow-hidden group"
            style={{
              width: media.length === 1 ? "100%" : "calc(50% - 4px)",
              maxWidth: media.length === 1 ? "100%" : "200px",
              aspectRatio: media.length === 1 ? "auto" : "1",
              border: "1.5px solid oklch(55% 0.04 70)",
              borderRadius: "3px",
            }}
          >
            {m.mediaType === "video" ? (
              <div className="w-full h-full relative" style={{ background: "oklch(20% 0.01 60)" }}>
                <video
                  src={m.mediaUrl}
                  className="w-full h-full object-cover"
                  muted
                  playsInline
                  preload="metadata"
                />
                <div
                  className="absolute inset-0 flex items-center justify-center"
                  style={{ background: "rgba(0,0,0,0.35)" }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center"
                    style={{ background: "rgba(255,255,255,0.85)" }}
                  >
                    <Video size={18} style={{ color: "oklch(25% 0.02 60)" }} />
                  </div>
                </div>
              </div>
            ) : (
              <img
                src={m.mediaUrl}
                alt=""
                className="w-full h-full object-cover"
                loading="lazy"
              />
            )}

            {/* Hover overlay */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
              style={{ background: "oklch(20% 0.02 60 / 0.3)" }}
            >
              {m.mediaType === "photo" ? (
                <Image size={20} style={{ color: "white" }} />
              ) : (
                <Video size={20} style={{ color: "white" }} />
              )}
            </div>

            {/* Multi-media badge */}
            {media.length > 1 && idx === 0 && (
              <span
                className="absolute bottom-1 right-1 px-1.5 py-0.5 text-xs font-bold"
                style={{
                  background: "oklch(20% 0.02 60 / 0.8)",
                  color: "white",
                  borderRadius: "2px",
                  fontFamily: "'Courier Prime', monospace",
                  fontSize: "0.65rem",
                }}
              >
                1/{media.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Lightbox overlay */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: "oklch(10% 0.01 60 / 0.95)" }}
          onClick={closeLightbox}
        >
          {/* Close button */}
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 p-2 cursor-pointer z-10"
            style={{ color: "oklch(90% 0.02 80)" }}
          >
            <X size={28} />
          </button>

          {/* Counter */}
          {media.length > 1 && (
            <div
              className="absolute top-4 left-1/2 -translate-x-1/2 px-3 py-1 z-10"
              style={{
                background: "oklch(25% 0.02 60 / 0.8)",
                borderRadius: "12px",
                fontFamily: "'Courier Prime', monospace",
                color: "oklch(85% 0.02 80)",
                fontSize: "0.85rem",
              }}
            >
              {lightboxIndex + 1} / {media.length}
            </div>
          )}

          {/* Previous */}
          {media.length > 1 && (
            <button
              onClick={(e) => { e.stopPropagation(); goPrev(); }}
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 cursor-pointer z-10 rounded-full"
              style={{ background: "oklch(25% 0.02 60 / 0.6)", color: "oklch(90% 0.02 80)" }}
            >
              <ChevronLeft size={28} />
            </button>
          )}

          {/* Next */}
          {media.length > 1 && (
            <button
              onClick={(e) => { e.stopPropagation(); goNext(); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 cursor-pointer z-10 rounded-full"
              style={{ background: "oklch(25% 0.02 60 / 0.6)", color: "oklch(90% 0.02 80)" }}
            >
              <ChevronRight size={28} />
            </button>
          )}

          {/* Media content */}
          <div
            className="max-w-4xl max-h-[85vh] w-full mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            {media[lightboxIndex].mediaType === "video" ? (
              <video
                key={media[lightboxIndex].id}
                src={media[lightboxIndex].mediaUrl}
                controls
                autoPlay
                playsInline
                className="w-full max-h-[85vh] object-contain"
                style={{ borderRadius: "4px" }}
              />
            ) : (
              <img
                key={media[lightboxIndex].id}
                src={media[lightboxIndex].mediaUrl}
                alt=""
                className="w-full max-h-[85vh] object-contain"
                style={{ borderRadius: "4px" }}
              />
            )}
          </div>
        </div>
      )}
    </>
  );
}
