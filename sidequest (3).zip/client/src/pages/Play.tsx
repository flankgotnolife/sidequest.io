import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState, useRef, useCallback } from "react";
import { toast } from "sonner";
import {
  Sword,
  RefreshCw,
  Camera,
  CheckCircle,
  Loader2,
  Star,
  X,
  ThumbsUp,
  ThumbsDown,
  Video,
  ListChecks,
  Upload,
  Aperture,
} from "lucide-react";
import CameraCapture from "@/components/CameraCapture";

const CATEGORIES = [
  "social", "creative", "physical", "food", "exploration", "random",
  "mindfulness", "tech", "weird", "dares", "photo", "skill",
  "community", "nature", "urban", "performance", "collectibles",
] as const;

const DIFFICULTIES = ["easy", "medium", "hard", "legendary"] as const;

const diffColor: Record<string, string> = {
  easy: "oklch(85% 0.1 140)",
  medium: "oklch(85% 0.12 80)",
  hard: "oklch(80% 0.14 30)",
  legendary: "oklch(75% 0.18 290)",
};

const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500MB
const MAX_FILES = 10;

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function DiffBadge({ diff }: { diff: string }) {
  return (
    <span
      className="px-2 py-0.5 text-sm font-bold uppercase"
      style={{
        background: diffColor[diff] ?? "oklch(90% 0.03 80)",
        color: "oklch(20% 0.02 60)",
        fontFamily: "'Courier Prime', monospace",
        fontSize: "0.7rem",
        letterSpacing: "0.1em",
        border: "1.5px solid oklch(25% 0.02 60)",
        borderRadius: "2px",
      }}
    >
      {diff}
    </span>
  );
}

type SelectedFile = {
  file: File;
  preview: string;
  mediaType: "photo" | "video";
};

type UploadedFile = {
  mediaUrl: string;
  mediaKey: string;
  mediaType: string;
  mimeType: string;
  originalName: string;
  size: number;
  order: number;
};

export default function Play() {
  const { isAuthenticated, user } = useAuth();
  const utils = trpc.useUtils();

  // Tab state
  const [activeTab, setActiveTab] = useState<"generate" | "incomplete">("generate");

  // Generate tab state
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | undefined>(undefined);

  // Completion state
  const [completingQuestId, setCompletingQuestId] = useState<number | null>(null);
  const [caption, setCaption] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<SelectedFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSpeed, setUploadSpeed] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [justCompleted, setJustCompleted] = useState<{ points: number; mediaCount: number } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // Camera state
  const [showCamera, setShowCamera] = useState(false);

  // Queries
  const { data: activeQuest, isLoading: loadingQuest } = trpc.sidequest.getActive.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const { data: incompleteQuests, isLoading: loadingIncomplete } = trpc.sidequest.getIncomplete.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // Mutations
  const generateMutation = trpc.sidequest.generate.useMutation({
    onSuccess: () => {
      utils.sidequest.getActive.invalidate();
      setJustCompleted(null);
      setSelectedFiles([]);
      setCaption("");
      setCompletingQuestId(null);
    },
    onError: (e: any) => toast.error(e.message),
  });

  const acceptMutation = trpc.sidequest.accept.useMutation({
    onSuccess: () => {
      utils.sidequest.getActive.invalidate();
      utils.sidequest.getIncomplete.invalidate();
      toast.success("Quest accepted! Check the Incomplete tab to complete it.");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const rejectMutation = trpc.sidequest.reject.useMutation({
    onSuccess: () => {
      utils.sidequest.getActive.invalidate();
      toast.info("Quest rejected. Generate a new one!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const submitMutation = trpc.completion.submit.useMutation({
    onSuccess: (data: any) => {
      setJustCompleted({ points: data.pointsEarned, mediaCount: data.mediaCount });
      setSelectedFiles([]);
      setCaption("");
      setCompletingQuestId(null);
      setUploadProgress(0);
      setUploadSpeed("");
      utils.sidequest.getActive.invalidate();
      utils.sidequest.getIncomplete.invalidate();
      utils.completion.getMyHistory.invalidate();
      toast.success(`Quest complete! +${data.pointsEarned} points!`);
    },
    onError: (e: any) => toast.error(e.message),
  });

  // File handling — store raw File objects, no base64
  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const maxToAdd = MAX_FILES - selectedFiles.length;
    const newFiles = Array.from(files).slice(0, maxToAdd);

    const validFiles: SelectedFile[] = [];
    for (const file of newFiles) {
      if (file.size > MAX_FILE_SIZE) {
        toast.error(`${file.name} is too large (max 500MB per file)`);
        continue;
      }
      const isVideo = file.type.startsWith("video/");
      const isPhoto = file.type.startsWith("image/");
      if (!isVideo && !isPhoto) {
        toast.error(`${file.name} is not a supported photo or video format`);
        continue;
      }
      validFiles.push({
        file,
        preview: URL.createObjectURL(file),
        mediaType: isVideo ? "video" : "photo",
      });
    }

    if (validFiles.length > 0) {
      setSelectedFiles((prev) => [...prev, ...validFiles]);
    }

    if (fileRef.current) fileRef.current.value = "";
  }, [selectedFiles.length]);

  // Camera capture handler
  const handleCameraCapture = useCallback((media: { file: File; preview: string; mediaType: "photo" | "video" }) => {
    if (selectedFiles.length >= MAX_FILES) {
      toast.error(`Maximum ${MAX_FILES} files allowed`);
      setShowCamera(false);
      return;
    }
    setSelectedFiles((prev) => [...prev, media]);
    setShowCamera(false);
    toast.success(`${media.mediaType === "photo" ? "Photo" : "Video"} captured!`);
  }, [selectedFiles.length]);

  function removeFile(index: number) {
    setSelectedFiles((prev) => {
      const removed = prev[index];
      if (removed) URL.revokeObjectURL(removed.preview);
      return prev.filter((_, i) => i !== index);
    });
  }

  // Upload files via direct multipart endpoint, then submit completion via tRPC
  async function handleSubmitCompletion(questId: number) {
    if (selectedFiles.length === 0) {
      toast.error("Upload at least one photo or video as proof!");
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setUploadSpeed("");

    try {
      // Build FormData with raw files
      const formData = new FormData();
      for (const sf of selectedFiles) {
        formData.append("files", sf.file);
      }

      // Upload via XMLHttpRequest for progress tracking
      const uploadResult = await new Promise<{ success: boolean; files: UploadedFile[] }>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const startTime = Date.now();

        xhr.upload.addEventListener("progress", (e) => {
          if (e.lengthComputable) {
            const pct = Math.round((e.loaded / e.total) * 100);
            setUploadProgress(pct);

            // Calculate speed
            const elapsed = (Date.now() - startTime) / 1000;
            if (elapsed > 0.5) {
              const speed = e.loaded / elapsed;
              setUploadSpeed(`${formatFileSize(Math.round(speed))}/s`);
            }
          }
        });

        xhr.addEventListener("load", () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              resolve(JSON.parse(xhr.responseText));
            } catch {
              reject(new Error("Invalid response from server"));
            }
          } else {
            try {
              const err = JSON.parse(xhr.responseText);
              reject(new Error(err.error || `Upload failed (${xhr.status})`));
            } catch {
              reject(new Error(`Upload failed (${xhr.status})`));
            }
          }
        });

        xhr.addEventListener("error", () => reject(new Error("Network error during upload")));
        xhr.addEventListener("abort", () => reject(new Error("Upload cancelled")));

        xhr.open("POST", "/api/upload");
        xhr.withCredentials = true;
        xhr.send(formData);
      });

      if (!uploadResult.success || !uploadResult.files?.length) {
        throw new Error("Upload failed — no files returned");
      }

      setUploading(false);
      setSubmitting(true);

      // Now submit the completion with the uploaded file URLs
      submitMutation.mutate(
        {
          sidequestId: questId,
          mediaFiles: uploadResult.files.map((f) => ({
            mediaUrl: f.mediaUrl,
            mediaKey: f.mediaKey,
            mimeType: f.mimeType,
            mediaType: f.mediaType as "photo" | "video",
          })),
          caption: caption || undefined,
        },
        { onSettled: () => setSubmitting(false) }
      );
    } catch (error: any) {
      console.error("Upload error:", error);
      toast.error(error.message || "Upload failed");
      setUploading(false);
      setSubmitting(false);
      setUploadProgress(0);
      setUploadSpeed("");
    }
  }

  // ─── Not logged in ─────────────────────────────────────────────────────────
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <div className="sketch-card max-w-md w-full text-center p-8">
          <Sword className="mx-auto mb-4" size={48} style={{ color: "oklch(45% 0.15 50)" }} />
          <h2 className="text-3xl mb-4" style={{ fontFamily: "'Permanent Marker', cursive" }}>
            Ready for Adventure?
          </h2>
          <p className="mb-6" style={{ fontFamily: "'Courier Prime', monospace" }}>
            Sign in to generate sidequests and start earning points!
          </p>
          <a
            href={getLoginUrl()}
            className="inline-block px-6 py-3 font-bold text-lg no-underline"
            style={{
              background: "oklch(75% 0.15 55)",
              color: "oklch(20% 0.02 60)",
              fontFamily: "'Permanent Marker', cursive",
              border: "2px solid oklch(25% 0.02 60)",
              borderRadius: "4px",
              boxShadow: "3px 3px 0 oklch(25% 0.02 60)",
            }}
          >
            Sign In to Play
          </a>
        </div>
      </div>
    );
  }

  const incompleteCount = incompleteQuests?.length ?? 0;
  const totalSelectedSize = selectedFiles.reduce((sum, sf) => sum + sf.file.size, 0);

  // ─── Shared proof upload form ──────────────────────────────────────────────
  function ProofUploadForm({ questId }: { questId: number }) {
    return (
      <div
        className="mt-4 p-4"
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "oklch(95% 0.02 80)",
          border: "1.5px dashed oklch(50% 0.05 60)",
          borderRadius: "4px",
        }}
      >
        <h4
          className="text-sm font-bold mb-3"
          style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(35% 0.03 60)" }}
        >
          Submit Proof
        </h4>

        {/* Hidden file input — accepts all image and video types */}
        <input
          ref={fileRef}
          type="file"
          accept="image/*,video/*,.mp4,.mov,.webm,.mkv,.avi,.m4v,.3gp,.hevc"
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />

        {/* Upload + Camera buttons */}
        <div className="flex gap-2 mb-3">
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              fileRef.current?.click();
            }}
            disabled={uploading || submitting}
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 transition-all hover:opacity-80 cursor-pointer disabled:opacity-50"
            style={{
              fontFamily: "'Courier Prime', monospace",
              fontSize: "0.85rem",
              background: "oklch(92% 0.04 80)",
              color: "oklch(30% 0.03 60)",
              border: "1.5px dashed oklch(45% 0.05 60)",
              borderRadius: "4px",
            }}
          >
            <Upload size={16} />
            Upload ({selectedFiles.length}/{MAX_FILES})
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setShowCamera(true);
            }}
            disabled={uploading || submitting || selectedFiles.length >= MAX_FILES}
            className="flex items-center justify-center gap-2 px-3 py-2.5 transition-all hover:opacity-80 cursor-pointer disabled:opacity-50"
            style={{
              fontFamily: "'Permanent Marker', cursive",
              fontSize: "0.85rem",
              background: "oklch(72% 0.15 50)",
              color: "oklch(15% 0.02 60)",
              border: "1.5px solid oklch(25% 0.02 60)",
              borderRadius: "4px",
            }}
          >
            <Aperture size={16} />
            Camera
          </button>
        </div>

        {/* File size info */}
        <p className="text-xs mb-2" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
          Supports 4K 60fps video up to 500MB per file &middot; {formatFileSize(totalSelectedSize)} selected
        </p>

        {/* Preview thumbnails */}
        {selectedFiles.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {selectedFiles.map((sf, idx) => (
              <div key={idx} className="relative" style={{ width: 72, height: 72 }}>
                {sf.mediaType === "video" ? (
                  <div className="w-full h-full relative">
                    <video
                      src={sf.preview}
                      className="w-full h-full object-cover"
                      style={{ border: "1px solid oklch(60% 0.03 60)", borderRadius: "3px" }}
                      muted
                      playsInline
                      preload="metadata"
                    />
                    <div
                      className="absolute inset-0 flex items-center justify-center"
                      style={{ background: "rgba(0,0,0,0.3)", borderRadius: "3px" }}
                    >
                      <Video size={18} style={{ color: "white" }} />
                    </div>
                    <span
                      className="absolute bottom-0.5 left-0.5 px-1 text-white"
                      style={{ fontSize: "0.55rem", background: "rgba(0,0,0,0.6)", borderRadius: "2px" }}
                    >
                      {formatFileSize(sf.file.size)}
                    </span>
                  </div>
                ) : (
                  <img
                    src={sf.preview}
                    alt={sf.file.name}
                    className="w-full h-full object-cover"
                    style={{ border: "1px solid oklch(60% 0.03 60)", borderRadius: "3px" }}
                  />
                )}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeFile(idx);
                  }}
                  disabled={uploading || submitting}
                  className="absolute -top-1.5 -right-1.5 rounded-full p-0.5 cursor-pointer"
                  style={{
                    background: "oklch(60% 0.15 25)",
                    color: "white",
                    border: "1px solid oklch(25% 0.02 60)",
                  }}
                >
                  <X size={12} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Upload progress bar */}
        {(uploading || submitting) && (
          <div className="mb-3">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(40% 0.03 60)" }}>
                {uploading ? "Uploading..." : "Saving completion..."}
              </span>
              <span className="text-xs" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(40% 0.03 60)" }}>
                {uploading ? `${uploadProgress}%` : ""} {uploadSpeed && `(${uploadSpeed})`}
              </span>
            </div>
            <div
              className="w-full h-3 overflow-hidden"
              style={{
                background: "oklch(90% 0.02 80)",
                border: "1.5px solid oklch(55% 0.03 60)",
                borderRadius: "2px",
              }}
            >
              <div
                className="h-full transition-all duration-300"
                style={{
                  width: uploading ? `${uploadProgress}%` : "100%",
                  background: uploading
                    ? "oklch(70% 0.15 55)"
                    : "oklch(65% 0.15 140)",
                  borderRadius: "1px",
                  animation: submitting ? "pulse 1.5s ease-in-out infinite" : undefined,
                }}
              />
            </div>
            <p className="text-xs mt-1" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
              {uploading
                ? `Uploading ${selectedFiles.length} file(s) (${formatFileSize(totalSelectedSize)})`
                : "Finalizing quest completion..."}
            </p>
          </div>
        )}

        {/* Caption */}
        <textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          onClick={(e) => e.stopPropagation()}
          onFocus={(e) => e.stopPropagation()}
          placeholder="Write a comment about your quest... (optional)"
          maxLength={280}
          rows={3}
          disabled={uploading || submitting}
          className="w-full px-3 py-2 mb-1 resize-none"
          style={{
            fontFamily: "'Courier Prime', monospace",
            fontSize: "0.85rem",
            background: "oklch(97% 0.01 80)",
            color: "oklch(25% 0.02 60)",
            border: "1.5px solid oklch(60% 0.03 60)",
            borderRadius: "4px",
            outline: "none",
          }}
        />
        <p className="text-xs mb-3" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
          {caption.length}/280
        </p>

        {/* Submit & Cancel */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              handleSubmitCompletion(questId);
            }}
            disabled={uploading || submitting || selectedFiles.length === 0}
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 font-bold transition-all hover:opacity-80 disabled:opacity-50 cursor-pointer"
            style={{
              background: selectedFiles.length === 0 ? "oklch(85% 0.03 60)" : "oklch(75% 0.15 140)",
              color: "oklch(20% 0.02 60)",
              fontFamily: "'Permanent Marker', cursive",
              border: "2px solid oklch(25% 0.02 60)",
              borderRadius: "4px",
            }}
          >
            {uploading ? (
              <>
                <Upload className="animate-pulse" size={16} />
                Uploading {uploadProgress}%...
              </>
            ) : submitting ? (
              <>
                <Loader2 className="animate-spin" size={16} />
                Submitting...
              </>
            ) : (
              <>
                <CheckCircle size={16} />
                Submit Proof
              </>
            )}
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (!uploading && !submitting) {
                setCompletingQuestId(null);
                setSelectedFiles([]);
                setCaption("");
                setUploadProgress(0);
                setUploadSpeed("");
              }
            }}
            disabled={uploading || submitting}
            className="px-3 py-2.5 transition-all hover:opacity-80 cursor-pointer disabled:opacity-50"
            style={{
              fontFamily: "'Courier Prime', monospace",
              fontSize: "0.85rem",
              background: "oklch(90% 0.03 60)",
              color: "oklch(35% 0.03 60)",
              border: "1.5px solid oklch(55% 0.03 60)",
              borderRadius: "4px",
            }}
          >
            Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <h1
          className="text-4xl md:text-5xl mb-2"
          style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(25% 0.02 60)" }}
        >
          Your Quest
        </h1>
        <p
          className="mb-6 text-sm"
          style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(45% 0.03 60)" }}
        >
          // {user?.name ?? "Adventurer"} &middot; generate &middot; accept &middot; complete &middot; earn points
        </p>

        {/* Tabs */}
        <div className="flex gap-0 mb-6">
          <button
            onClick={() => {
              setActiveTab("generate");
              setCompletingQuestId(null);
              setSelectedFiles([]);
              setCaption("");
            }}
            className="px-5 py-2.5 font-bold text-sm transition-all cursor-pointer"
            style={{
              fontFamily: "'Caveat', cursive",
              fontSize: "1.1rem",
              background: activeTab === "generate" ? "oklch(75% 0.15 55)" : "transparent",
              color: "oklch(25% 0.02 60)",
              border: "2px solid oklch(25% 0.02 60)",
              borderRight: "none",
              borderRadius: "4px 0 0 4px",
            }}
          >
            Generate Quest
          </button>
          <button
            onClick={() => {
              setActiveTab("incomplete");
              setCompletingQuestId(null);
              setSelectedFiles([]);
              setCaption("");
            }}
            className="px-5 py-2.5 font-bold text-sm transition-all cursor-pointer"
            style={{
              fontFamily: "'Caveat', cursive",
              fontSize: "1.1rem",
              background: activeTab === "incomplete" ? "oklch(75% 0.15 55)" : "transparent",
              color: "oklch(25% 0.02 60)",
              border: "2px solid oklch(25% 0.02 60)",
              borderRadius: "0 4px 4px 0",
            }}
          >
            Incomplete ({incompleteCount})
          </button>
        </div>

        {/* ─── GENERATE TAB ─────────────────────────────────────────────────── */}
        {activeTab === "generate" && (
          <div>
            {/* Just completed celebration */}
            {justCompleted && (
              <div className="sketch-card p-6 mb-6 text-center" style={{ background: "oklch(92% 0.08 140)" }}>
                <CheckCircle className="mx-auto mb-3" size={48} style={{ color: "oklch(50% 0.2 140)" }} />
                <h3
                  className="text-2xl mb-2"
                  style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(30% 0.05 140)" }}
                >
                  Quest Complete!
                </h3>
                <p style={{ fontFamily: "'Courier Prime', monospace" }}>
                  +{justCompleted.points} points &middot; {justCompleted.mediaCount} file(s) uploaded
                </p>
              </div>
            )}

            {/* Loading */}
            {loadingQuest && (
              <div className="sketch-card p-8 text-center">
                <Loader2 className="animate-spin mx-auto mb-3" size={32} />
                <p style={{ fontFamily: "'Courier Prime', monospace" }}>Loading quest...</p>
              </div>
            )}

            {/* Active quest card with Accept/Reject */}
            {!loadingQuest && activeQuest && (
              <div className="sketch-card p-6 mb-6">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{activeQuest.emoji}</span>
                    <DiffBadge diff={activeQuest.difficulty} />
                  </div>
                  <span
                    className="font-bold"
                    style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(50% 0.15 55)" }}
                  >
                    <Star size={14} className="inline mr-1" style={{ color: diffColor[activeQuest.difficulty] }} />
                    {activeQuest.points} pts
                  </span>
                </div>

                <h3
                  className="text-xl mb-2"
                  style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(25% 0.02 60)" }}
                >
                  {activeQuest.title}
                </h3>

                <p
                  className="mb-2 text-sm"
                  style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(40% 0.03 60)" }}
                >
                  {activeQuest.description}
                </p>

                <span
                  className="inline-block px-2 py-0.5 text-xs mb-4"
                  style={{
                    fontFamily: "'Courier Prime', monospace",
                    background: "oklch(90% 0.03 80)",
                    border: "1px dashed oklch(50% 0.03 60)",
                    borderRadius: "2px",
                  }}
                >
                  {activeQuest.category}
                </span>

                {/* Accept / Reject buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => acceptMutation.mutate({ sidequestId: activeQuest.id })}
                    disabled={acceptMutation.isPending || rejectMutation.isPending}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 font-bold transition-all hover:opacity-80 disabled:opacity-50 cursor-pointer"
                    style={{
                      background: "oklch(75% 0.15 140)",
                      color: "oklch(20% 0.02 60)",
                      fontFamily: "'Permanent Marker', cursive",
                      border: "2px solid oklch(25% 0.02 60)",
                      borderRadius: "4px",
                      fontSize: "1.1rem",
                    }}
                  >
                    {acceptMutation.isPending ? (
                      <Loader2 className="animate-spin" size={18} />
                    ) : (
                      <ThumbsUp size={18} />
                    )}
                    Accept
                  </button>
                  <button
                    onClick={() => rejectMutation.mutate({ sidequestId: activeQuest.id })}
                    disabled={acceptMutation.isPending || rejectMutation.isPending}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 font-bold transition-all hover:opacity-80 disabled:opacity-50 cursor-pointer"
                    style={{
                      background: "oklch(80% 0.12 25)",
                      color: "oklch(20% 0.02 60)",
                      fontFamily: "'Permanent Marker', cursive",
                      border: "2px solid oklch(25% 0.02 60)",
                      borderRadius: "4px",
                      fontSize: "1.1rem",
                    }}
                  >
                    {rejectMutation.isPending ? (
                      <Loader2 className="animate-spin" size={18} />
                    ) : (
                      <ThumbsDown size={18} />
                    )}
                    Reject
                  </button>
                </div>
              </div>
            )}

            {/* No active quest — show generate controls */}
            {!loadingQuest && !activeQuest && !justCompleted && (
              <div className="sketch-card p-6 mb-6 text-center">
                <Sword className="mx-auto mb-3" size={40} style={{ color: "oklch(50% 0.1 55)" }} />
                <p className="mb-2" style={{ fontFamily: "'Courier Prime', monospace" }}>
                  No active quest. Generate one to get started!
                </p>
              </div>
            )}

            {/* Category & Difficulty selectors */}
            <div className="sketch-card p-4 mb-4">
              <p
                className="text-sm mb-2 font-bold"
                style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(40% 0.03 60)" }}
              >
                Category (optional):
              </p>
              <div className="flex flex-wrap gap-1.5 mb-4">
                <button
                  onClick={() => setSelectedCategory(undefined)}
                  className="px-2 py-1 text-xs transition-all cursor-pointer"
                  style={{
                    fontFamily: "'Courier Prime', monospace",
                    background: !selectedCategory ? "oklch(75% 0.15 55)" : "oklch(95% 0.02 80)",
                    color: "oklch(25% 0.02 60)",
                    border: "1.5px solid oklch(25% 0.02 60)",
                    borderRadius: "2px",
                  }}
                >
                  random
                </button>
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className="px-2 py-1 text-xs transition-all cursor-pointer"
                    style={{
                      fontFamily: "'Courier Prime', monospace",
                      background: selectedCategory === cat ? "oklch(75% 0.15 55)" : "oklch(95% 0.02 80)",
                      color: "oklch(25% 0.02 60)",
                      border: "1.5px solid oklch(25% 0.02 60)",
                      borderRadius: "2px",
                    }}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <p
                className="text-sm mb-2 font-bold"
                style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(40% 0.03 60)" }}
              >
                Difficulty (optional):
              </p>
              <div className="flex flex-wrap gap-1.5 mb-4">
                <button
                  onClick={() => setSelectedDifficulty(undefined)}
                  className="px-2 py-1 text-xs transition-all cursor-pointer"
                  style={{
                    fontFamily: "'Courier Prime', monospace",
                    background: !selectedDifficulty ? "oklch(75% 0.15 55)" : "oklch(95% 0.02 80)",
                    color: "oklch(25% 0.02 60)",
                    border: "1.5px solid oklch(25% 0.02 60)",
                    borderRadius: "2px",
                  }}
                >
                  any
                </button>
                {DIFFICULTIES.map((diff) => (
                  <button
                    key={diff}
                    onClick={() => setSelectedDifficulty(diff)}
                    className="px-2 py-1 text-xs transition-all cursor-pointer"
                    style={{
                      fontFamily: "'Courier Prime', monospace",
                      background: selectedDifficulty === diff ? diffColor[diff] : "oklch(95% 0.02 80)",
                      color: "oklch(25% 0.02 60)",
                      border: "1.5px solid oklch(25% 0.02 60)",
                      borderRadius: "2px",
                    }}
                  >
                    {diff}
                  </button>
                ))}
              </div>

              <button
                onClick={() =>
                  generateMutation.mutate({
                    category: selectedCategory as any,
                    difficulty: selectedDifficulty as any,
                  })
                }
                disabled={generateMutation.isPending}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 font-bold transition-all hover:opacity-80 disabled:opacity-50 cursor-pointer"
                style={{
                  background: "oklch(75% 0.15 55)",
                  color: "oklch(20% 0.02 60)",
                  fontFamily: "'Permanent Marker', cursive",
                  border: "2px solid oklch(25% 0.02 60)",
                  borderRadius: "4px",
                  fontSize: "1.1rem",
                }}
              >
                {generateMutation.isPending ? (
                  <>
                    <Loader2 className="animate-spin" size={20} />
                    Generating...
                  </>
                ) : (
                  <>
                    <RefreshCw size={20} />
                    Generate Quest
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* ─── INCOMPLETE TAB ───────────────────────────────────────────────── */}
        {activeTab === "incomplete" && (
          <div>
            {loadingIncomplete && (
              <div className="sketch-card p-8 text-center">
                <Loader2 className="animate-spin mx-auto mb-3" size={32} />
                <p style={{ fontFamily: "'Courier Prime', monospace" }}>Loading quests...</p>
              </div>
            )}

            {!loadingIncomplete && incompleteCount === 0 && (
              <div className="sketch-card p-8 text-center">
                <ListChecks className="mx-auto mb-3" size={48} style={{ color: "oklch(60% 0.05 60)" }} />
                <p className="mb-2" style={{ fontFamily: "'Courier Prime', monospace" }}>
                  No incomplete quests yet.
                </p>
                <p className="text-sm" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(50% 0.03 60)" }}>
                  Generate and accept quests to see them here!
                </p>
                <button
                  onClick={() => setActiveTab("generate")}
                  className="mt-4 px-4 py-2 font-bold transition-all hover:opacity-80 cursor-pointer"
                  style={{
                    background: "oklch(75% 0.15 55)",
                    color: "oklch(20% 0.02 60)",
                    fontFamily: "'Permanent Marker', cursive",
                    border: "2px solid oklch(25% 0.02 60)",
                    borderRadius: "4px",
                  }}
                >
                  Generate Quest
                </button>
              </div>
            )}

            {!loadingIncomplete &&
              incompleteQuests?.map((quest: any) => (
                <div key={quest.id} className="sketch-card p-5 mb-4">
                  {/* Quest info */}
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{quest.emoji}</span>
                      <DiffBadge diff={quest.difficulty} />
                    </div>
                    <span
                      className="font-bold text-sm"
                      style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(50% 0.15 55)" }}
                    >
                      <Star size={12} className="inline mr-1" style={{ color: diffColor[quest.difficulty] }} />
                      {quest.points} pts
                    </span>
                  </div>

                  <h3
                    className="text-lg mb-1"
                    style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(25% 0.02 60)" }}
                  >
                    {quest.title}
                  </h3>

                  <p
                    className="mb-2 text-sm"
                    style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(40% 0.03 60)" }}
                  >
                    {quest.description}
                  </p>

                  <span
                    className="inline-block px-2 py-0.5 text-xs mb-3"
                    style={{
                      fontFamily: "'Courier Prime', monospace",
                      background: "oklch(90% 0.03 80)",
                      border: "1px dashed oklch(50% 0.03 60)",
                      borderRadius: "2px",
                    }}
                  >
                    {quest.category}
                  </span>

                  {/* Complete button or completion form */}
                  {completingQuestId === quest.id ? (
                    <ProofUploadForm questId={quest.id} />
                  ) : (
                    <button
                      onClick={() => {
                        setCompletingQuestId(quest.id);
                        setSelectedFiles([]);
                        setCaption("");
                      }}
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 mt-2 font-bold transition-all hover:opacity-80 cursor-pointer"
                      style={{
                        background: "oklch(75% 0.15 140)",
                        color: "oklch(20% 0.02 60)",
                        fontFamily: "'Permanent Marker', cursive",
                        border: "2px solid oklch(25% 0.02 60)",
                        borderRadius: "4px",
                        fontSize: "1rem",
                      }}
                    >
                      <CheckCircle size={18} />
                      Complete Quest
                    </button>
                  )}
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Camera overlay */}
      {showCamera && (
        <CameraCapture
          onCapture={handleCameraCapture}
          onClose={() => setShowCamera(false)}
        />
      )}
    </div>
  );
}
