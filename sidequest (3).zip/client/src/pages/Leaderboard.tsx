import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Trophy, Star, Crown, Medal, Users, Globe } from "lucide-react";
import { Link } from "wouter";

const RANK_ICONS = [
  <Crown size={18} style={{ color: "oklch(72% 0.18 85)" }} />,
  <Medal size={18} style={{ color: "oklch(70% 0.08 60)" }} />,
  <Medal size={18} style={{ color: "oklch(65% 0.12 50)" }} />,
];

function LeaderRow({ rank, entry, isMe }: { rank: number; entry: any; isMe: boolean }) {
  const topColors = ["oklch(95% 0.08 85)", "oklch(95% 0.05 60)", "oklch(95% 0.06 50)"];
  const bg = rank <= 3 ? topColors[rank - 1] : "oklch(97.5% 0.025 80)";

  return (
    <Link
      href={`/profile/${entry.id}`}
      className="flex items-center gap-3 p-3 no-underline transition-all hover:translate-x-1"
      style={{
        background: isMe ? "oklch(90% 0.08 140)" : bg,
        border: `2px solid ${isMe ? "oklch(50% 0.12 140)" : "oklch(70% 0.04 70)"}`,
        borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
        boxShadow: rank <= 3 ? "3px 3px 0 oklch(25% 0.02 60)" : "2px 2px 0 oklch(70% 0.04 70)",
        marginBottom: "6px",
      }}
    >
      {/* Rank */}
      <div
        className="w-8 text-center flex-shrink-0"
        style={{ fontFamily: "'Permanent Marker', cursive", fontSize: "1rem", color: "oklch(30% 0.02 60)" }}
      >
        {rank <= 3 ? RANK_ICONS[rank - 1] : `#${rank}`}
      </div>

      {/* Avatar */}
      <div
        className="w-9 h-9 flex-shrink-0 flex items-center justify-center text-lg"
        style={{
          background: "oklch(90% 0.04 80)",
          border: "2px solid oklch(55% 0.04 70)",
          borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
          overflow: "hidden",
        }}
      >
        {entry.avatarUrl ? (
          <img src={entry.avatarUrl} alt="" className="w-full h-full object-cover" />
        ) : (
          <span>{(entry.name ?? "?")[0]?.toUpperCase()}</span>
        )}
      </div>

      {/* Name */}
      <div className="flex-1 min-w-0">
        <div
          className="truncate"
          style={{ fontFamily: "'Caveat', cursive", fontWeight: 700, fontSize: "1.1rem", color: "oklch(20% 0.02 60)" }}
        >
          {entry.name ?? "Anonymous"}
          {isMe && (
            <span
              className="ml-2 text-xs px-1.5 py-0.5"
              style={{
                fontFamily: "'Courier Prime', monospace",
                background: "oklch(50% 0.12 140)",
                color: "white",
                borderRadius: "2px",
                fontSize: "0.65rem",
                letterSpacing: "0.05em",
              }}
            >
              YOU
            </span>
          )}
        </div>
        <div
          className="text-xs"
          style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}
        >
          {entry.completedCount} quest{entry.completedCount !== 1 ? "s" : ""} completed
        </div>
      </div>

      {/* Points */}
      <div
        className="flex items-center gap-1 flex-shrink-0"
        style={{ fontFamily: "'Permanent Marker', cursive", fontSize: "1.1rem", color: "oklch(35% 0.1 50)" }}
      >
        <Star size={13} />
        {entry.totalPoints}
      </div>
    </Link>
  );
}

export default function Leaderboard() {
  const { user, isAuthenticated } = useAuth();
  const [tab, setTab] = useState<"global" | "friends">("global");

  const { data: globalData, isLoading: loadingGlobal } = trpc.leaderboard.global.useQuery({ limit: 50 });
  const { data: friendsData, isLoading: loadingFriends } = trpc.leaderboard.friends.useQuery(undefined, {
    enabled: isAuthenticated && tab === "friends",
  });

  const data = tab === "global" ? globalData : friendsData;
  const loading = tab === "global" ? loadingGlobal : loadingFriends;

  return (
    <div className="container py-8 max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-5xl mb-1" style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}>
          Leaderboard
        </h1>
        <p className="text-sm" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
          // who's the ultimate sidequest champion?
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {([["global", <Globe size={14} />, "Global"], ["friends", <Users size={14} />, "Friends"]] as const).map(([key, icon, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className="flex items-center gap-1.5 px-4 py-2 sketch-btn"
            style={{
              background: tab === key ? "oklch(25% 0.02 60)" : "transparent",
              color: tab === key ? "oklch(97% 0.02 85)" : "oklch(30% 0.02 60)",
              fontSize: "1rem",
            }}
          >
            {icon}
            {label}
          </button>
        ))}
      </div>

      {/* Friends tab — not authenticated */}
      {tab === "friends" && !isAuthenticated && (
        <div className="sketch-card p-8 text-center">
          <Users size={32} className="mx-auto mb-3" style={{ color: "oklch(60% 0.04 70)" }} />
          <p style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(50% 0.04 70)" }}>
            Sign in to see your friends leaderboard
          </p>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="space-y-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="h-14 animate-pulse"
              style={{ background: "oklch(92% 0.025 80)", borderRadius: "4px" }}
            />
          ))}
        </div>
      )}

      {/* Empty */}
      {!loading && (!data || data.length === 0) && (
        <div className="sketch-card p-10 text-center">
          <Trophy size={36} className="mx-auto mb-3" style={{ color: "oklch(65% 0.04 70)" }} />
          <h3 className="text-2xl mb-2" style={{ fontFamily: "'Caveat', cursive" }}>No entries yet</h3>
          <p style={{ fontFamily: "'Courier Prime', monospace", fontSize: "0.85rem", color: "oklch(55% 0.04 70)" }}>
            {tab === "friends" ? "Add friends and complete quests to see rankings!" : "Be the first to complete a quest!"}
          </p>
        </div>
      )}

      {/* List */}
      {!loading && data && data.length > 0 && (
        <div>
          {data.map((entry, i) => (
            <LeaderRow
              key={entry.id}
              rank={i + 1}
              entry={entry}
              isMe={isAuthenticated && user?.id === entry.id}
            />
          ))}
        </div>
      )}
    </div>
  );
}
