import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { Sword, Trophy, Camera, Users, Zap, Star } from "lucide-react";

const features = [
  { icon: Zap, title: "Random Quests", desc: "AI generates wild, unique challenges just for you. No two quests are the same.", color: "oklch(85% 0.12 80)" },
  { icon: Camera, title: "Photo Proof", desc: "Complete the quest, snap a photo, submit your evidence. No cheating allowed!", color: "oklch(85% 0.1 140)" },
  { icon: Trophy, title: "Leaderboard", desc: "Rack up points and climb the ranks. Can you reach the top?", color: "oklch(85% 0.14 50)" },
  { icon: Users, title: "Friend Battles", desc: "Challenge your friends and compete on a private leaderboard.", color: "oklch(80% 0.14 290)" },
];

const difficulties = [
  { label: "Easy", points: "10 pts", color: "oklch(85% 0.1 140)", desc: "Quick 5-15 min tasks" },
  { label: "Medium", points: "25 pts", color: "oklch(85% 0.12 80)", desc: "30-60 min adventures" },
  { label: "Hard", points: "50 pts", color: "oklch(80% 0.14 30)", desc: "1-3 hour challenges" },
  { label: "Legendary", points: "100 pts", color: "oklch(75% 0.18 290)", desc: "Epic multi-day quests" },
];

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen" style={{ background: "oklch(97% 0.02 85)" }}>
      {/* Hero */}
      <section className="container py-16 md:py-24">
        <div className="max-w-3xl mx-auto text-center">
          {/* Decorative dashes */}
          <div className="flex justify-center gap-2 mb-6">
            {["- - -", "✕", "- - -"].map((t, i) => (
              <span key={i} style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(60% 0.04 70)", fontSize: "0.8rem" }}>{t}</span>
            ))}
          </div>

          <h1
            className="text-6xl md:text-8xl mb-4 leading-none"
            style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}
          >
            SideQuest
          </h1>

          <div
            className="inline-block px-4 py-1 mb-6 text-sm"
            style={{
              fontFamily: "'Courier Prime', monospace",
              border: "1.5px dashed oklch(50% 0.04 70)",
              color: "oklch(45% 0.04 70)",
              borderRadius: "2px",
            }}
          >
            ⚔️ random challenges · 📸 photo proof · 🏆 compete with friends
          </div>

          <p
            className="text-xl md:text-2xl mb-10 leading-relaxed"
            style={{ fontFamily: "'Caveat', cursive", color: "oklch(35% 0.03 60)", fontWeight: 500 }}
          >
            Get a random real-world challenge. Complete it. Prove it with a photo.
            <br />
            <span style={{ fontFamily: "'Courier Prime', monospace", fontSize: "0.95rem", color: "oklch(50% 0.04 70)" }}>
              // climb the leaderboard. beat your friends.
            </span>
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {isAuthenticated ? (
              <Link
                href="/play"
                className="inline-flex items-center gap-2 px-8 py-3 no-underline sketch-btn"
                style={{ background: "oklch(72% 0.15 50)", color: "oklch(15% 0.02 60)", fontSize: "1.2rem" }}
              >
                <Sword size={18} />
                Start a Quest!
              </Link>
            ) : (
              <a
                href={getLoginUrl()}
                className="inline-flex items-center gap-2 px-8 py-3 no-underline sketch-btn"
                style={{ background: "oklch(72% 0.15 50)", color: "oklch(15% 0.02 60)", fontSize: "1.2rem" }}
              >
                <Sword size={18} />
                Start Questing — Free!
              </a>
            )}
            <Link
              href="/leaderboard"
              className="inline-flex items-center gap-2 px-8 py-3 no-underline sketch-btn"
              style={{ background: "transparent", color: "oklch(25% 0.02 60)", fontSize: "1.2rem" }}
            >
              <Trophy size={18} />
              See Leaderboard
            </Link>
          </div>

          {/* Decorative bottom line */}
          <div className="mt-12 flex items-center gap-3 justify-center">
            <div style={{ flex: 1, height: "2px", background: "repeating-linear-gradient(90deg, oklch(60% 0.04 70) 0, oklch(60% 0.04 70) 6px, transparent 6px, transparent 12px)" }} />
            <Star size={14} style={{ color: "oklch(60% 0.04 70)" }} />
            <div style={{ flex: 1, height: "2px", background: "repeating-linear-gradient(90deg, oklch(60% 0.04 70) 0, oklch(60% 0.04 70) 6px, transparent 6px, transparent 12px)" }} />
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container pb-16">
        <h2
          className="text-4xl text-center mb-10"
          style={{ fontFamily: "'Caveat', cursive", color: "oklch(25% 0.02 60)" }}
        >
          How it works
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map(({ icon: Icon, title, desc, color }, i) => (
            <div
              key={i}
              className="p-5 sketch-card"
              style={{ background: "oklch(97.5% 0.025 80)" }}
            >
              <div
                className="w-10 h-10 flex items-center justify-center mb-3"
                style={{
                  background: color,
                  border: "2px solid oklch(25% 0.02 60)",
                  borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
                }}
              >
                <Icon size={18} style={{ color: "oklch(20% 0.02 60)" }} />
              </div>
              <h3
                className="text-xl mb-2"
                style={{ fontFamily: "'Caveat', cursive", color: "oklch(20% 0.02 60)" }}
              >
                {title}
              </h3>
              <p
                className="text-sm leading-relaxed"
                style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(45% 0.03 60)" }}
              >
                {desc}
              </p>
              <div
                className="mt-3 text-xs"
                style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(65% 0.04 70)" }}
              >
                [{String(i + 1).padStart(2, "0")}]
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Difficulty levels */}
      <section
        className="py-14"
        style={{ background: "oklch(94% 0.03 80)", borderTop: "2px solid oklch(70% 0.04 70)", borderBottom: "2px solid oklch(70% 0.04 70)" }}
      >
        <div className="container">
          <h2
            className="text-4xl text-center mb-2"
            style={{ fontFamily: "'Caveat', cursive", color: "oklch(25% 0.02 60)" }}
          >
            Difficulty &amp; Points
          </h2>
          <p
            className="text-center mb-8 text-sm"
            style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(50% 0.04 70)" }}
          >
            // harder quests = more points
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            {difficulties.map(({ label, points, color, desc }) => (
              <div
                key={label}
                className="p-4 text-center"
                style={{
                  background: color,
                  border: "2px solid oklch(25% 0.02 60)",
                  borderRadius: "2px 8px 3px 7px / 7px 3px 8px 2px",
                  boxShadow: "3px 3px 0 oklch(25% 0.02 60)",
                }}
              >
                <div
                  className="text-xl font-bold mb-1"
                  style={{ fontFamily: "'Caveat', cursive", color: "oklch(20% 0.02 60)" }}
                >
                  {label}
                </div>
                <div
                  className="text-lg font-bold"
                  style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}
                >
                  {points}
                </div>
                <div
                  className="text-xs mt-1"
                  style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(35% 0.03 60)" }}
                >
                  {desc}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container py-16 text-center">
        <h2
          className="text-5xl mb-4"
          style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}
        >
          Ready for your first quest?
        </h2>
        <p
          className="mb-8 text-lg"
          style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(45% 0.04 70)" }}
        >
          Sign in for free. No app download needed.
        </p>
        {!isAuthenticated && (
          <a
            href={getLoginUrl()}
            className="inline-flex items-center gap-2 px-10 py-4 no-underline sketch-btn"
            style={{ background: "oklch(25% 0.02 60)", color: "oklch(97% 0.02 85)", fontSize: "1.3rem" }}
          >
            <Sword size={20} />
            Let's Go! ⚔️
          </a>
        )}
        {isAuthenticated && (
          <Link
            href="/play"
            className="inline-flex items-center gap-2 px-10 py-4 no-underline sketch-btn"
            style={{ background: "oklch(25% 0.02 60)", color: "oklch(97% 0.02 85)", fontSize: "1.3rem" }}
          >
            <Sword size={20} />
            Let's Go! ⚔️
          </Link>
        )}
      </section>

      {/* Footer */}
      <footer
        className="py-6 text-center"
        style={{
          borderTop: "2px dashed oklch(70% 0.04 70)",
          fontFamily: "'Courier Prime', monospace",
          color: "oklch(60% 0.04 70)",
          fontSize: "0.8rem",
        }}
      >
        SideQuest — go touch grass ✕ made with ♥
      </footer>
    </div>
  );
}
