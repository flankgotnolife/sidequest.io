import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useParams } from "wouter";
import {
  Star,
  CheckCircle,
  Calendar,
  Trophy,
  Loader2,
  Pencil,
  X,
  Camera,
  Save,
} from "lucide-react";
import { useState, useRef } from "react";
import { toast } from "sonner";
import MediaGallery from "@/components/MediaGallery";

const diffColor: Record<string, string> = {
  easy: "oklch(85% 0.1 140)",
  medium: "oklch(85% 0.12 80)",
  hard: "oklch(80% 0.14 30)",
  legendary: "oklch(75% 0.18 290)",
};

function CompletionCard({ c }: { c: any }) {
  const [expanded, setExpanded] = useState(false);
  const hasMedia = c.media && c.media.length > 0;

  return (
    <div
      className="sketch-card overflow-hidden cursor-pointer"
      onClick={() => setExpanded(!expanded)}
    >
      <div className="relative">
        {/* Show first media item as thumbnail */}
        {hasMedia && c.media[0].mediaType === "video" ? (
          <div className="w-full h-40 relative" style={{ background: "oklch(20% 0.01 60)" }}>
            <video
              src={c.media[0].mediaUrl}
              className="w-full h-40 object-cover"
              muted
              playsInline
              preload="metadata"
            />
            <div
              className="absolute inset-0 flex items-center justify-center"
              style={{ background: "rgba(0,0,0,0.25)" }}
            >
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.85)" }}
              >
                <span style={{ fontSize: "1.2rem" }}>▶</span>
              </div>
            </div>
          </div>
        ) : (
          <img
            src={hasMedia ? c.media[0].mediaUrl : c.photoUrl}
            alt={c.title}
            className="w-full h-40 object-cover"
          />
        )}

        <div
          className="absolute top-2 left-2 px-2 py-0.5 text-xs"
          style={{
            background: diffColor[c.difficulty] ?? "oklch(90% 0.03 80)",
            border: "1.5px solid oklch(25% 0.02 60)",
            borderRadius: "2px",
            fontFamily: "'Courier Prime', monospace",
            color: "oklch(20% 0.02 60)",
            fontWeight: 700,
            textTransform: "uppercase",
            letterSpacing: "0.08em",
          }}
        >
          {c.difficulty}
        </div>
        <div
          className="absolute top-2 right-2 flex items-center gap-0.5 px-2 py-0.5"
          style={{
            background: "oklch(25% 0.02 60 / 0.85)",
            borderRadius: "2px",
            fontFamily: "'Permanent Marker', cursive",
            fontSize: "0.85rem",
            color: "oklch(90% 0.1 85)",
          }}
        >
          <Star size={10} />
          {c.pointsEarned}
        </div>

        {/* Multi-media badge */}
        {hasMedia && c.media.length > 1 && (
          <div
            className="absolute bottom-2 right-2 px-2 py-0.5 text-xs font-bold"
            style={{
              background: "oklch(20% 0.02 60 / 0.8)",
              color: "white",
              borderRadius: "2px",
              fontFamily: "'Courier Prime', monospace",
            }}
          >
            {c.media.length} files
          </div>
        )}
      </div>
      <div className="p-3">
        <div className="flex items-center gap-1.5 mb-1">
          <span className="text-xl">{c.emoji}</span>
          <h4
            className="text-base leading-tight"
            style={{ fontFamily: "'Caveat', cursive", color: "oklch(20% 0.02 60)", fontWeight: 700 }}
          >
            {c.title}
          </h4>
        </div>
        {expanded && (
          <div onClick={(e) => e.stopPropagation()}>
            <p
              className="text-xs mb-2 leading-relaxed"
              style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(45% 0.03 60)" }}
            >
              {c.description}
            </p>
            {c.caption && (
              <p
                className="text-sm italic mb-2"
                style={{ fontFamily: "'Caveat', cursive", color: "oklch(40% 0.04 70)", fontSize: "1rem" }}
              >
                "{c.caption}"
              </p>
            )}
            {/* Full media gallery */}
            {hasMedia && (
              <div className="mt-3">
                <MediaGallery media={c.media} />
              </div>
            )}
          </div>
        )}
        <div
          className="text-xs"
          style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(60% 0.04 70)" }}
        >
          {new Date(c.completedAt).toLocaleDateString()}
        </div>
      </div>
    </div>
  );
}

export default function Profile() {
  const { user: me, isAuthenticated } = useAuth();
  const params = useParams<{ id?: string }>();
  const profileId = params.id ? parseInt(params.id) : me?.id;
  const utils = trpc.useUtils();

  // Edit state
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editBio, setEditBio] = useState("");
  const [avatarUploading, setAvatarUploading] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const { data: profile, isLoading: loadingProfile } = trpc.user.getProfile.useQuery(
    { userId: profileId! },
    { enabled: !!profileId }
  );

  const { data: history, isLoading: loadingHistory } = trpc.completion.getUserHistory.useQuery(
    { userId: profileId! },
    { enabled: !!profileId }
  );

  const updateProfileMutation = trpc.user.updateProfile.useMutation({
    onSuccess: () => {
      utils.user.getProfile.invalidate({ userId: profileId! });
      utils.auth.me.invalidate();
      setEditing(false);
      toast.success("Profile updated!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const isOwnProfile = isAuthenticated && me?.id === profileId;

  const startEditing = () => {
    setEditName(profile?.name ?? "");
    setEditBio((profile as any)?.bio ?? "");
    setEditing(true);
  };

  const saveProfile = () => {
    updateProfileMutation.mutate({
      name: editName || undefined,
      bio: editBio || undefined,
    });
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Avatar must be under 5MB");
      return;
    }

    setAvatarUploading(true);
    try {
      const formData = new FormData();
      formData.append("files", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) throw new Error("Upload failed");

      const result = await response.json();
      if (result.success && result.files?.[0]) {
        updateProfileMutation.mutate({ avatarUrl: result.files[0].mediaUrl });
      }
    } catch (err: any) {
      toast.error("Failed to upload avatar");
    } finally {
      setAvatarUploading(false);
      if (avatarInputRef.current) avatarInputRef.current.value = "";
    }
  };

  if (!profileId) {
    return (
      <div className="container py-20 text-center">
        <p style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
          Sign in to view your profile.
        </p>
      </div>
    );
  }

  if (loadingProfile) {
    return (
      <div className="container py-20 text-center">
        <Loader2 className="animate-spin mx-auto" style={{ color: "oklch(50% 0.04 70)" }} />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="container py-20 text-center">
        <p style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
          User not found.
        </p>
      </div>
    );
  }

  return (
    <div className="container py-8 max-w-3xl mx-auto">
      {/* Profile header */}
      <div className="sketch-card p-6 mb-8">
        <div className="flex items-start gap-5">
          {/* Avatar with upload option */}
          <div className="relative flex-shrink-0">
            <div
              className="w-20 h-20 flex items-center justify-center text-3xl"
              style={{
                background: "oklch(90% 0.04 80)",
                border: "2px solid oklch(25% 0.02 60)",
                borderRadius: "2px 8px 3px 7px / 7px 3px 8px 2px",
                boxShadow: "3px 3px 0 oklch(25% 0.02 60)",
                overflow: "hidden",
              }}
            >
              {avatarUploading ? (
                <Loader2 className="animate-spin" size={24} style={{ color: "oklch(50% 0.04 70)" }} />
              ) : profile.avatarUrl ? (
                <img src={profile.avatarUrl} alt="" className="w-full h-full object-cover" />
              ) : (
                <span>{(profile.name ?? "?")[0]?.toUpperCase()}</span>
              )}
            </div>
            {isOwnProfile && (
              <>
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  disabled={avatarUploading}
                  className="absolute -bottom-1 -right-1 p-1 rounded-full cursor-pointer"
                  style={{
                    background: "oklch(72% 0.15 50)",
                    border: "1.5px solid oklch(25% 0.02 60)",
                    color: "oklch(15% 0.02 60)",
                  }}
                  title="Change avatar"
                >
                  <Camera size={12} />
                </button>
              </>
            )}
          </div>

          <div className="flex-1">
            {editing ? (
              /* Edit mode */
              <div>
                <input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="Your name"
                  maxLength={50}
                  className="w-full px-3 py-2 mb-2"
                  style={{
                    fontFamily: "'Permanent Marker', cursive",
                    fontSize: "1.5rem",
                    background: "oklch(97% 0.01 80)",
                    color: "oklch(20% 0.02 60)",
                    border: "1.5px solid oklch(55% 0.04 70)",
                    borderRadius: "4px",
                    outline: "none",
                  }}
                />
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  placeholder="Write a short bio... (optional)"
                  maxLength={200}
                  rows={2}
                  className="w-full px-3 py-2 mb-2 resize-none"
                  style={{
                    fontFamily: "'Courier Prime', monospace",
                    fontSize: "0.85rem",
                    background: "oklch(97% 0.01 80)",
                    color: "oklch(25% 0.02 60)",
                    border: "1.5px solid oklch(55% 0.04 70)",
                    borderRadius: "4px",
                    outline: "none",
                  }}
                />
                <p className="text-xs mb-3" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
                  {editBio.length}/200
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={saveProfile}
                    disabled={updateProfileMutation.isPending}
                    className="flex items-center gap-1.5 px-4 py-2 font-bold cursor-pointer transition-all hover:opacity-80 disabled:opacity-50"
                    style={{
                      fontFamily: "'Permanent Marker', cursive",
                      background: "oklch(72% 0.15 50)",
                      color: "oklch(15% 0.02 60)",
                      border: "2px solid oklch(25% 0.02 60)",
                      borderRadius: "4px",
                    }}
                  >
                    {updateProfileMutation.isPending ? (
                      <Loader2 className="animate-spin" size={14} />
                    ) : (
                      <Save size={14} />
                    )}
                    Save
                  </button>
                  <button
                    onClick={() => setEditing(false)}
                    disabled={updateProfileMutation.isPending}
                    className="flex items-center gap-1.5 px-4 py-2 cursor-pointer transition-all hover:opacity-80"
                    style={{
                      fontFamily: "'Courier Prime', monospace",
                      fontSize: "0.85rem",
                      background: "oklch(90% 0.03 60)",
                      color: "oklch(35% 0.03 60)",
                      border: "1.5px solid oklch(55% 0.03 60)",
                      borderRadius: "4px",
                    }}
                  >
                    <X size={14} />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              /* View mode */
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h1
                    className="text-4xl"
                    style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}
                  >
                    {profile.name ?? "Anonymous"}
                  </h1>
                  {isOwnProfile && (
                    <span
                      className="text-sm px-2 py-0.5"
                      style={{
                        fontFamily: "'Courier Prime', monospace",
                        background: "oklch(72% 0.15 50)",
                        color: "oklch(15% 0.02 60)",
                        borderRadius: "2px",
                        fontSize: "0.7rem",
                        letterSpacing: "0.05em",
                      }}
                    >
                      YOU
                    </span>
                  )}
                  {isOwnProfile && (
                    <button
                      onClick={startEditing}
                      className="ml-2 p-1.5 cursor-pointer transition-all hover:opacity-70"
                      style={{
                        background: "oklch(90% 0.03 80)",
                        border: "1.5px solid oklch(55% 0.04 70)",
                        borderRadius: "3px",
                        color: "oklch(40% 0.04 70)",
                      }}
                      title="Edit profile"
                    >
                      <Pencil size={14} />
                    </button>
                  )}
                </div>

                {/* Bio */}
                {(profile as any)?.bio && (
                  <p
                    className="mb-2 italic"
                    style={{ fontFamily: "'Caveat', cursive", fontSize: "1.1rem", color: "oklch(40% 0.04 70)" }}
                  >
                    "{(profile as any).bio}"
                  </p>
                )}

                <p
                  className="text-sm mb-4"
                  style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}
                >
                  member since {new Date(profile.createdAt).toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                </p>
                <div className="flex gap-4 flex-wrap">
                  <div
                    className="flex items-center gap-1.5 px-3 py-1.5"
                    style={{
                      background: "oklch(85% 0.12 80)",
                      border: "2px solid oklch(25% 0.02 60)",
                      borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
                      boxShadow: "2px 2px 0 oklch(25% 0.02 60)",
                    }}
                  >
                    <Star size={14} style={{ color: "oklch(40% 0.1 50)" }} />
                    <span style={{ fontFamily: "'Permanent Marker', cursive", fontSize: "1.1rem", color: "oklch(25% 0.02 60)" }}>
                      {profile.totalPoints} pts
                    </span>
                  </div>
                  <div
                    className="flex items-center gap-1.5 px-3 py-1.5"
                    style={{
                      background: "oklch(85% 0.1 140)",
                      border: "2px solid oklch(25% 0.02 60)",
                      borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
                      boxShadow: "2px 2px 0 oklch(25% 0.02 60)",
                    }}
                  >
                    <CheckCircle size={14} style={{ color: "oklch(35% 0.1 140)" }} />
                    <span style={{ fontFamily: "'Permanent Marker', cursive", fontSize: "1.1rem", color: "oklch(25% 0.02 60)" }}>
                      {profile.completedCount} quests
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quest history */}
      <div>
        <div className="flex items-center gap-2 mb-5">
          <Calendar size={18} style={{ color: "oklch(45% 0.04 70)" }} />
          <h2
            className="text-3xl"
            style={{ fontFamily: "'Caveat', cursive", color: "oklch(25% 0.02 60)" }}
          >
            Quest History
          </h2>
          <span
            className="ml-1 px-2 py-0.5 text-xs"
            style={{
              fontFamily: "'Courier Prime', monospace",
              background: "oklch(90% 0.03 80)",
              border: "1px solid oklch(65% 0.04 70)",
              borderRadius: "2px",
              color: "oklch(45% 0.04 70)",
            }}
          >
            {history?.length ?? 0}
          </span>
        </div>

        {loadingHistory && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-52 animate-pulse" style={{ background: "oklch(92% 0.025 80)", borderRadius: "4px" }} />
            ))}
          </div>
        )}

        {!loadingHistory && (!history || history.length === 0) && (
          <div className="sketch-card p-10 text-center">
            <Trophy size={32} className="mx-auto mb-3" style={{ color: "oklch(65% 0.04 70)" }} />
            <h3 className="text-2xl mb-2" style={{ fontFamily: "'Caveat', cursive" }}>No quests yet</h3>
            <p style={{ fontFamily: "'Courier Prime', monospace", fontSize: "0.85rem", color: "oklch(55% 0.04 70)" }}>
              {isOwnProfile ? "Go complete your first sidequest!" : "This adventurer hasn't completed any quests yet."}
            </p>
          </div>
        )}

        {!loadingHistory && history && history.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {history.map((c) => (
              <CompletionCard key={c.id} c={c} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
