import { trpc } from "@/lib/trpc";
import { Star, Rss, Loader2, Video, Image } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import MediaGallery from "@/components/MediaGallery";

const diffColor: Record<string, string> = {
  easy: "oklch(85% 0.1 140)",
  medium: "oklch(85% 0.12 80)",
  hard: "oklch(80% 0.14 30)",
  legendary: "oklch(75% 0.18 290)",
};

function FeedCard({ item }: { item: any }) {
  const [expanded, setExpanded] = useState(false);
  const hasMedia = item.media && item.media.length > 0;
  const firstMedia = hasMedia ? item.media[0] : null;

  return (
    <div
      className="sketch-card overflow-hidden"
      style={{ marginBottom: "16px" }}
    >
      {/* Primary media / photo */}
      <div className="relative cursor-pointer" onClick={() => setExpanded(!expanded)}>
        {firstMedia && firstMedia.mediaType === "video" ? (
          <div className="w-full relative" style={{ maxHeight: "320px", background: "oklch(15% 0.01 60)" }}>
            <video
              src={firstMedia.mediaUrl}
              className="w-full object-cover"
              style={{ maxHeight: "320px" }}
              muted
              playsInline
              preload="metadata"
            />
            <div
              className="absolute inset-0 flex items-center justify-center"
              style={{ background: "rgba(0,0,0,0.25)" }}
            >
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.85)" }}
              >
                <span style={{ fontSize: "1.5rem", marginLeft: "3px" }}>▶</span>
              </div>
            </div>
          </div>
        ) : (
          <img
            src={firstMedia ? firstMedia.mediaUrl : item.photoUrl}
            alt={item.title}
            className="w-full object-cover"
            style={{ maxHeight: "320px" }}
          />
        )}

        <div
          className="absolute top-3 left-3 px-2 py-0.5 text-xs"
          style={{
            background: diffColor[item.difficulty] ?? "oklch(90% 0.03 80)",
            border: "1.5px solid oklch(25% 0.02 60)",
            borderRadius: "2px",
            fontFamily: "'Courier Prime', monospace",
            color: "oklch(20% 0.02 60)",
            fontWeight: 700,
            textTransform: "uppercase",
            letterSpacing: "0.08em",
          }}
        >
          {item.difficulty}
        </div>
        <div
          className="absolute top-3 right-3 flex items-center gap-0.5 px-2 py-0.5"
          style={{
            background: "oklch(20% 0.02 60 / 0.8)",
            borderRadius: "2px",
            fontFamily: "'Permanent Marker', cursive",
            fontSize: "0.9rem",
            color: "oklch(90% 0.1 85)",
          }}
        >
          <Star size={11} />
          {item.pointsEarned}
        </div>

        {/* Multi-media badge */}
        {hasMedia && item.media.length > 1 && (
          <div
            className="absolute bottom-3 right-3 flex items-center gap-1 px-2 py-0.5"
            style={{
              background: "oklch(20% 0.02 60 / 0.8)",
              borderRadius: "2px",
              fontFamily: "'Courier Prime', monospace",
              fontSize: "0.75rem",
              color: "white",
            }}
          >
            {item.media.filter((m: any) => m.mediaType === "photo").length > 0 && (
              <span className="flex items-center gap-0.5">
                <Image size={10} />
                {item.media.filter((m: any) => m.mediaType === "photo").length}
              </span>
            )}
            {item.media.filter((m: any) => m.mediaType === "video").length > 0 && (
              <span className="flex items-center gap-0.5">
                <Video size={10} />
                {item.media.filter((m: any) => m.mediaType === "video").length}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        {/* User */}
        <Link
          href={`/profile/${item.userId}`}
          className="flex items-center gap-2 mb-3 no-underline"
        >
          <div
            className="w-7 h-7 flex items-center justify-center text-sm flex-shrink-0"
            style={{
              background: "oklch(90% 0.04 80)",
              border: "1.5px solid oklch(55% 0.04 70)",
              borderRadius: "2px 5px 3px 4px",
              overflow: "hidden",
            }}
          >
            {item.userAvatarUrl ? (
              <img src={item.userAvatarUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              <span style={{ fontSize: "0.75rem" }}>{(item.userName ?? "?")[0]?.toUpperCase()}</span>
            )}
          </div>
          <span
            style={{ fontFamily: "'Caveat', cursive", fontWeight: 700, fontSize: "1rem", color: "oklch(25% 0.02 60)" }}
          >
            {item.userName ?? "Anonymous"}
          </span>
          <span
            className="ml-auto text-xs"
            style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(60% 0.04 70)" }}
          >
            {new Date(item.completedAt).toLocaleDateString()}
          </span>
        </Link>

        {/* Quest title */}
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl">{item.emoji}</span>
          <h3
            className="text-xl leading-tight"
            style={{ fontFamily: "'Caveat', cursive", color: "oklch(20% 0.02 60)", fontWeight: 700 }}
          >
            {item.title}
          </h3>
        </div>

        {/* Category */}
        <span
          className="inline-block mb-2 px-2 py-0.5 text-xs uppercase"
          style={{
            fontFamily: "'Courier Prime', monospace",
            letterSpacing: "0.08em",
            border: "1.5px solid oklch(65% 0.04 70)",
            borderRadius: "2px",
            color: "oklch(50% 0.04 70)",
          }}
        >
          {item.category}
        </span>

        {/* Caption */}
        {item.caption && (
          <p
            className="mt-2 italic"
            style={{ fontFamily: "'Caveat', cursive", fontSize: "1.05rem", color: "oklch(40% 0.04 70)" }}
          >
            "{item.caption}"
          </p>
        )}

        {/* Expanded media gallery */}
        {expanded && hasMedia && (
          <div className="mt-4 pt-3" style={{ borderTop: "1px dashed oklch(70% 0.03 70)" }}>
            <p
              className="text-xs mb-2 font-bold uppercase"
              style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(50% 0.04 70)", letterSpacing: "0.1em" }}
            >
              All proof ({item.media.length})
            </p>
            <MediaGallery media={item.media} />
          </div>
        )}

        {/* Show more prompt */}
        {hasMedia && item.media.length > 1 && !expanded && (
          <button
            onClick={() => setExpanded(true)}
            className="mt-2 text-xs cursor-pointer hover:opacity-70 transition-opacity"
            style={{
              fontFamily: "'Courier Prime', monospace",
              color: "oklch(50% 0.1 50)",
              background: "none",
              border: "none",
              padding: 0,
              textDecoration: "underline",
            }}
          >
            View all {item.media.length} files →
          </button>
        )}
      </div>
    </div>
  );
}

export default function Feed() {
  const { data, isLoading } = trpc.completion.getRecent.useQuery({ limit: 30 });

  return (
    <div className="container py-8 max-w-xl mx-auto">
      <div className="mb-8">
        <h1 className="text-5xl mb-1" style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}>
          Quest Feed
        </h1>
        <p className="text-sm" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
          // see what everyone's been up to
        </p>
      </div>

      {isLoading && (
        <div className="text-center py-16">
          <Loader2 className="animate-spin mx-auto mb-3" style={{ color: "oklch(55% 0.04 70)" }} />
          <p style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>Loading feed...</p>
        </div>
      )}

      {!isLoading && (!data || data.length === 0) && (
        <div className="sketch-card p-12 text-center">
          <Rss size={36} className="mx-auto mb-4" style={{ color: "oklch(65% 0.04 70)" }} />
          <h2 className="text-3xl mb-2" style={{ fontFamily: "'Caveat', cursive" }}>No completions yet</h2>
          <p style={{ fontFamily: "'Courier Prime', monospace", fontSize: "0.85rem", color: "oklch(55% 0.04 70)" }}>
            Be the first to complete a sidequest and show up here!
          </p>
          <Link
            href="/play"
            className="inline-flex items-center gap-2 mt-5 px-6 py-2 sketch-btn no-underline"
            style={{ background: "oklch(72% 0.15 50)", color: "oklch(15% 0.02 60)" }}
          >
            Start a Quest →
          </Link>
        </div>
      )}

      {!isLoading && data && data.map((item) => (
        <FeedCard key={item.id} item={item} />
      ))}
    </div>
  );
}
