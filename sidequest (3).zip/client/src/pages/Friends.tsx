import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Search, UserPlus, Check, X, Users, Star, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";

function FriendCard({ friend }: { friend: any }) {
  return (
    <Link
      href={`/profile/${friend.friendId}`}
      className="flex items-center gap-3 p-3 no-underline hover:translate-x-1 transition-transform"
      style={{
        background: "oklch(97.5% 0.025 80)",
        border: "2px solid oklch(70% 0.04 70)",
        borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
        boxShadow: "2px 2px 0 oklch(70% 0.04 70)",
        marginBottom: "6px",
      }}
    >
      <div
        className="w-10 h-10 flex-shrink-0 flex items-center justify-center text-lg"
        style={{
          background: "oklch(90% 0.04 80)",
          border: "2px solid oklch(55% 0.04 70)",
          borderRadius: "2px 6px 3px 5px / 5px 3px 6px 2px",
          overflow: "hidden",
        }}
      >
        {friend.friendAvatarUrl ? (
          <img src={friend.friendAvatarUrl} alt="" className="w-full h-full object-cover" />
        ) : (
          <span>{(friend.friendName ?? "?")[0]?.toUpperCase()}</span>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div
          className="truncate"
          style={{ fontFamily: "'Caveat', cursive", fontWeight: 700, fontSize: "1.1rem", color: "oklch(20% 0.02 60)" }}
        >
          {friend.friendName ?? "Anonymous"}
        </div>
        <div
          className="text-xs"
          style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}
        >
          {friend.friendCompletedCount} quests completed
        </div>
      </div>
      <div
        className="flex items-center gap-1"
        style={{ fontFamily: "'Permanent Marker', cursive", fontSize: "1rem", color: "oklch(40% 0.1 50)" }}
      >
        <Star size={12} />
        {friend.friendTotalPoints}
      </div>
    </Link>
  );
}

export default function Friends() {
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  const { data: friends, isLoading: loadingFriends } = trpc.friends.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: pending, isLoading: loadingPending } = trpc.friends.getPending.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: searchResults, isLoading: searching } = trpc.user.search.useQuery(
    { query: debouncedQuery },
    { enabled: isAuthenticated && debouncedQuery.length >= 2 }
  );

  const sendRequest = trpc.friends.sendRequest.useMutation({
    onSuccess: () => {
      toast.success("Friend request sent!");
      utils.friends.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const respond = trpc.friends.respondRequest.useMutation({
    onSuccess: (_, vars: any) => {
      toast.success(vars.status === "accepted" ? "Friend accepted!" : "Request declined");
      utils.friends.getPending.invalidate();
      utils.friends.list.invalidate();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const handleSearch = (val: string) => {
    setSearchQuery(val);
    const t = setTimeout(() => setDebouncedQuery(val), 400);
    return () => clearTimeout(t);
  };

  if (!isAuthenticated) {
    return (
      <div className="container py-20 text-center">
        <div className="max-w-md mx-auto sketch-card p-10">
          <Users size={36} className="mx-auto mb-4" style={{ color: "oklch(60% 0.04 70)" }} />
          <h2 className="text-4xl mb-3" style={{ fontFamily: "'Caveat', cursive" }}>Sign in to add friends</h2>
          <a
            href={getLoginUrl()}
            className="inline-flex items-center gap-2 px-6 py-3 sketch-btn no-underline"
            style={{ background: "oklch(72% 0.15 50)", color: "oklch(15% 0.02 60)", fontSize: "1.1rem" }}
          >
            Sign In Free
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8 max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-5xl mb-1" style={{ fontFamily: "'Permanent Marker', cursive", color: "oklch(20% 0.02 60)" }}>
          Friends
        </h1>
        <p className="text-sm" style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}>
          // find friends · challenge them · dominate the leaderboard
        </p>
      </div>

      {/* Search */}
      <div className="sketch-card p-5 mb-6">
        <h3 className="text-xl mb-3" style={{ fontFamily: "'Caveat', cursive", color: "oklch(25% 0.02 60)" }}>
          Find People
        </h3>
        <div className="relative mb-4">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2"
            style={{ color: "oklch(55% 0.04 70)" }}
          />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search by name..."
            className="w-full pl-9 pr-4 py-2 outline-none"
            style={{
              fontFamily: "'Courier Prime', monospace",
              fontSize: "0.9rem",
              background: "oklch(95% 0.02 80)",
              border: "2px solid oklch(65% 0.04 70)",
              borderRadius: "2px 5px 3px 4px",
              color: "oklch(25% 0.02 60)",
            }}
          />
        </div>

        {searching && (
          <div className="flex items-center gap-2 py-2" style={{ color: "oklch(55% 0.04 70)" }}>
            <Loader2 size={14} className="animate-spin" />
            <span style={{ fontFamily: "'Courier Prime', monospace", fontSize: "0.85rem" }}>Searching...</span>
          </div>
        )}

        {searchResults && searchResults.length > 0 && (
          <div className="space-y-2">
            {searchResults.map((u: any) => (
              <div
                key={u.id}
                className="flex items-center gap-3 p-2"
                style={{
                  background: "oklch(95% 0.02 80)",
                  border: "1.5px dashed oklch(65% 0.04 70)",
                  borderRadius: "2px 5px 3px 4px",
                }}
              >
                <div
                  className="w-8 h-8 flex items-center justify-center text-sm flex-shrink-0"
                  style={{
                    background: "oklch(90% 0.04 80)",
                    border: "1.5px solid oklch(55% 0.04 70)",
                    borderRadius: "2px 5px 3px 4px",
                    overflow: "hidden",
                  }}
                >
                  {u.avatarUrl ? (
                    <img src={u.avatarUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span>{(u.name ?? "?")[0]?.toUpperCase()}</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div
                    className="truncate"
                    style={{ fontFamily: "'Caveat', cursive", fontWeight: 700, fontSize: "1rem", color: "oklch(20% 0.02 60)" }}
                  >
                    {u.name ?? "Anonymous"}
                  </div>
                  <div
                    className="text-xs"
                    style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}
                  >
                    {u.completedCount} quests · {u.totalPoints} pts
                  </div>
                </div>
                <button
                  onClick={() => sendRequest.mutate({ userId: u.id })}
                  disabled={sendRequest.isPending}
                  className="flex items-center gap-1 px-3 py-1.5 sketch-btn"
                  style={{
                    background: "oklch(72% 0.15 50)",
                    color: "oklch(15% 0.02 60)",
                    fontSize: "0.85rem",
                  }}
                >
                  <UserPlus size={12} />
                  Add
                </button>
              </div>
            ))}
          </div>
        )}

        {debouncedQuery.length >= 2 && !searching && searchResults?.length === 0 && (
          <p style={{ fontFamily: "'Courier Prime', monospace", fontSize: "0.85rem", color: "oklch(55% 0.04 70)" }}>
            No users found for "{debouncedQuery}"
          </p>
        )}
      </div>

      {/* Pending requests */}
      {pending && pending.length > 0 && (
        <div className="sketch-card p-5 mb-6">
          <h3 className="text-xl mb-3" style={{ fontFamily: "'Caveat', cursive", color: "oklch(25% 0.02 60)" }}>
            Pending Requests
            <span
              className="ml-2 px-1.5 py-0.5 text-xs"
              style={{
                fontFamily: "'Courier Prime', monospace",
                background: "oklch(80% 0.14 30)",
                color: "oklch(20% 0.02 60)",
                borderRadius: "2px",
                fontSize: "0.7rem",
              }}
            >
              {pending.length}
            </span>
          </h3>
          <div className="space-y-2">
            {pending.map((req) => (
              <div
                key={req.id}
                className="flex items-center gap-3 p-2"
                style={{
                  background: "oklch(93% 0.04 80)",
                  border: "1.5px solid oklch(65% 0.04 70)",
                  borderRadius: "2px 5px 3px 4px",
                }}
              >
                <div
                  className="w-8 h-8 flex items-center justify-center text-sm flex-shrink-0"
                  style={{
                    background: "oklch(90% 0.04 80)",
                    border: "1.5px solid oklch(55% 0.04 70)",
                    borderRadius: "2px 5px 3px 4px",
                    overflow: "hidden",
                  }}
                >
                  {req.requesterAvatarUrl ? (
                    <img src={req.requesterAvatarUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span>{(req.requesterName ?? "?")[0]?.toUpperCase()}</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div
                    className="truncate"
                    style={{ fontFamily: "'Caveat', cursive", fontWeight: 700, fontSize: "1rem", color: "oklch(20% 0.02 60)" }}
                  >
                    {req.requesterName ?? "Anonymous"}
                  </div>
                  <div
                    className="text-xs"
                    style={{ fontFamily: "'Courier Prime', monospace", color: "oklch(55% 0.04 70)" }}
                  >
                    wants to be friends
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => respond.mutate({ friendshipId: req.id, status: "accepted" })}
                    className="p-1.5 sketch-btn"
                    style={{ background: "oklch(85% 0.1 140)", color: "oklch(25% 0.08 140)" }}
                  >
                    <Check size={14} />
                  </button>
                  <button
                    onClick={() => respond.mutate({ friendshipId: req.id, status: "declined" })}
                    className="p-1.5 sketch-btn"
                    style={{ background: "oklch(80% 0.14 30)", color: "oklch(20% 0.08 30)" }}
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Friends list */}
      <div>
        <h3 className="text-2xl mb-4" style={{ fontFamily: "'Caveat', cursive", color: "oklch(25% 0.02 60)" }}>
          Your Friends
          {friends && friends.length > 0 && (
            <span
              className="ml-2 px-1.5 py-0.5 text-xs"
              style={{
                fontFamily: "'Courier Prime', monospace",
                background: "oklch(90% 0.03 80)",
                border: "1px solid oklch(65% 0.04 70)",
                borderRadius: "2px",
                color: "oklch(45% 0.04 70)",
              }}
            >
              {friends.length}
            </span>
          )}
        </h3>

        {loadingFriends && (
          <div className="space-y-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-14 animate-pulse" style={{ background: "oklch(92% 0.025 80)", borderRadius: "4px" }} />
            ))}
          </div>
        )}

        {!loadingFriends && (!friends || friends.length === 0) && (
          <div className="sketch-card p-8 text-center">
            <Users size={28} className="mx-auto mb-3" style={{ color: "oklch(65% 0.04 70)" }} />
            <p style={{ fontFamily: "'Courier Prime', monospace", fontSize: "0.85rem", color: "oklch(55% 0.04 70)" }}>
              No friends yet. Search for people above!
            </p>
          </div>
        )}

        {!loadingFriends && friends && friends.map((f: any) => <FriendCard key={f.friendshipId} friend={f} />)}
      </div>
    </div>
  );
}
