import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  DIFFICULTY_POINTS,
  SIDEQUEST_CATEGORIES,
} from "../drizzle/schema";
import { invokeLLM } from "./_core/llm";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  acceptSidequest,
  deactivateSidequest,
  getActiveSidequestForUser,
  getCompletionById,
  getFriendshipStatus,
  getFriendsLeaderboard,
  getGlobalLeaderboard,
  getIncompleteSidequests,
  getPendingFriendRequests,
  getRecentCompletions,
  getSidequestById,
  getUserById,
  getUserCompletions,
  getUserFriends,
  hasUserCompletedSidequest,
  incrementUserPoints,
  rejectSidequest,
  respondToFriendRequest,
  saveSidequest,
  saveCompletion,
  saveMediaFiles,
  searchUsers,
  sendFriendRequest,
  getUserPastQuestTitles,
  updateUserProfile,
  getMediaFilesForCompletions,
  getMediaFilesForCompletion,
} from "./db";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

// ─── Auth Router ─────────────────────────────────────────────────────────────

const authRouter = router({
  me: publicProcedure.query((opts) => opts.ctx.user),
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true } as const;
  }),
});

// ─── Sidequest Router ─────────────────────────────────────────────────────────

const sidequestRouter = router({
  generate: protectedProcedure
    .input(
      z.object({
        category: z.enum([...SIDEQUEST_CATEGORIES] as [string, ...string[]]).optional(),
        difficulty: z.enum(["easy", "medium", "hard", "legendary"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const category = input.category ?? SIDEQUEST_CATEGORIES[Math.floor(Math.random() * SIDEQUEST_CATEGORIES.length)];
      const difficulty = input.difficulty ?? (["easy", "easy", "medium", "medium", "hard", "legendary"] as const)[Math.floor(Math.random() * 6)];

      // Fetch past quest titles to prevent duplicates
      const pastTitles = await getUserPastQuestTitles(ctx.user.id);

      // Random flavor modifiers to inject variety into every generation
      const toneModifiers = [
        "chaotic goblin energy", "wholesome but unhinged", "like a fever dream",
        "absurdly wholesome", "maximum cringe (in a good way)", "suspiciously specific",
        "oddly poetic", "like a dare from your weirdest friend", "aggressively random",
        "so dumb it's genius", "weirdly motivational", "mildly cursed",
        "like a deleted scene from a comedy movie", "chaotic neutral energy",
        "the kind of thing you'd only do on a dare", "unhinged but safe",
        "like something a mischievous wizard would assign", "peak absurdity",
        "the definition of 'why not?'", "gloriously pointless",
      ];
      const settingModifiers = [
        "at a park", "in a grocery store", "at a bus stop", "in your neighborhood",
        "at a coffee shop", "in a library (quietly!)", "at a mall", "on a sidewalk",
        "in your kitchen", "at a gas station", "near a fountain", "at a bookstore",
        "in a parking lot", "at a laundromat", "near a statue or monument",
        "at a pet store", "in a thrift shop", "at a fast food place",
        "at a playground (when empty)", "in your backyard",
      ];
      const propModifiers = [
        "involving a hat", "using only one hand", "while wearing sunglasses indoors",
        "with a rubber duck", "using a spoon as a prop", "with a cardboard sign",
        "involving a houseplant", "with a silly walk", "using tape creatively",
        "involving a sock puppet", "with an umbrella (no rain)", "using sticky notes",
        "involving a blanket cape", "with a fake mustache", "using only items from your pocket",
        "with a paper airplane", "involving a balloon", "using chopsticks for everything",
        "with a traffic cone (if you can find one)", "involving a stuffed animal",
      ];

      const randomTone = toneModifiers[Math.floor(Math.random() * toneModifiers.length)];
      const randomSetting = settingModifiers[Math.floor(Math.random() * settingModifiers.length)];
      const randomProp = propModifiers[Math.floor(Math.random() * propModifiers.length)];
      const randomSeed = Math.floor(Math.random() * 999999);

      const systemPrompt = `You are a HILARIOUS, ABSURD sidequest generator for a social challenge app. Your job is to create FUNNY, ENTERTAINING, and MEMORABLE challenges that make people laugh and have a blast.

CRITICAL RULE: Every quest you generate MUST be completely unique and different from anything generated before. NEVER repeat a concept, theme, or approach. Each quest should feel like a brand new adventure.

Generate a single, specific, achievable real-world sidequest challenge that is:
- HILARIOUS or ABSURD (make people laugh or cringe in a good way)
- Concrete and actionable (something you can actually photograph/video as proof)
- Safe but slightly embarrassing or weird
- Appropriate for the category and difficulty level
- CREATIVE and UNEXPECTED (avoid generic challenges)
- COMPLETELY DIFFERENT from any quest listed in the "ALREADY USED" section below

Difficulty guidelines:
- Easy: 5-15 minutes, silly but quick (e.g., funny poses, quick interactions, absurd outfits)
- Medium: 15-60 minutes, requires boldness (e.g., convince strangers, create something funny, public silliness)
- Hard: 1-3 hours, major embarrassment factor (e.g., public performance, elaborate pranks, sustained weirdness)
- Legendary: Multi-day or EPIC (e.g., viral-worthy stunts, massive time investment, legendary status)

Category-specific vibes:
- weird: ABSURD and NONSENSICAL (do something that makes no sense, embrace chaos)
- dares: BOLD and EMBARRASSING (push comfort zones, be brave)
- photo: CREATIVE COMPOSITION (specific photo requirements, artistic)
- skill: LEARN or PRACTICE something new
- community: HELP or CONNECT with others, spread joy
- nature: OUTDOOR ADVENTURE and exploration
- urban: EXPLORE hidden city spots, urban discovery
- performance: SING, DANCE, ACT in public (the weirder the better)
- collectibles: FIND or COLLECT specific things
- social: INTERACT with strangers in funny ways
- creative: MAKE something absurd or hilarious
- physical: ATHLETIC or MOVEMENT-based silliness
- food: FOOD-related challenges (eating challenges, food art, weird food combos)
- exploration: DISCOVER hidden gems
- random: COMPLETELY RANDOM and UNPREDICTABLE
- mindfulness: PEACEFUL but with a twist of weirdness
- tech: TECH-related challenges

Respond ONLY with valid JSON matching this exact schema:
{
  "title": "short catchy title (max 8 words)",
  "description": "detailed description of what to do and what photo/video to take as proof (2-3 sentences). Be specific, funny, and entertaining!",
  "emoji": "single relevant emoji"
}`;

      // Build the user prompt with past titles and random modifiers
      let userPrompt = `[Seed: ${randomSeed}] Generate a ${difficulty} difficulty sidequest in the "${category}" category.\n\nVIBE: ${randomTone}\nSUGGESTED SETTING: ${randomSetting}\nOPTIONAL TWIST: ${randomProp}\n\nMake it HILARIOUS, ENTERTAINING, and MEMORABLE! Be absurd, be bold, be funny! Use the vibe, setting, and twist as INSPIRATION (not literally) to create something totally fresh and original.`;

      if (pastTitles.length > 0) {
        userPrompt += `\n\n--- ALREADY USED (DO NOT REPEAT OR MAKE SIMILAR) ---\n${pastTitles.map((t, i) => `${i + 1}. ${t}`).join("\n")}\n--- END OF USED LIST ---\n\nYou MUST generate something COMPLETELY DIFFERENT from ALL of the above. Different concept, different activity, different approach. Be wildly creative!`;
      }

      // Helper to normalize titles for comparison
      const normalize = (t: string) => t.toLowerCase().replace(/[^a-z0-9]/g, "");
      const pastNormalized = new Set(pastTitles.map(normalize));

      let parsed: { title: string; description: string; emoji: string };
      const MAX_RETRIES = 3;
      let attempts = 0;

      while (attempts < MAX_RETRIES) {
        attempts++;
        try {
          // Vary the seed on retries to get different results
          const retrySeed = randomSeed + attempts * 137;
          const retryPrompt = attempts > 1
            ? userPrompt.replace(`[Seed: ${randomSeed}]`, `[Seed: ${retrySeed}] [Attempt ${attempts} - MUST be completely different from previous attempts]`)
            : userPrompt;

          const response = await invokeLLM({
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: retryPrompt },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "sidequest",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    description: { type: "string" },
                    emoji: { type: "string" },
                  },
                  required: ["title", "description", "emoji"],
                  additionalProperties: false,
                },
              },
            },
          });
          const content = response.choices[0]?.message.content;
          if (!content || typeof content !== "string") throw new Error("No content in response");
          const candidate = JSON.parse(content);

          // Check if this title is a duplicate
          if (pastNormalized.has(normalize(candidate.title))) {
            console.warn(`[SideQuest] Duplicate title detected on attempt ${attempts}: "${candidate.title}", retrying...`);
            continue;
          }

          parsed = candidate;
          break;
        } catch (error) {
          if (attempts >= MAX_RETRIES) {
            console.error("LLM error after retries:", error);
            throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to generate sidequest" });
          }
        }
      }

      // If all retries produced duplicates, use the last attempt anyway
      if (!parsed!) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to generate a unique sidequest" });
      }

      const points = DIFFICULTY_POINTS[difficulty];

      // Deactivate any existing active sidequest for this user
      const existing = await getActiveSidequestForUser(ctx.user.id);
      if (existing) {
        await deactivateSidequest(existing.id);
      }

      const id = await saveSidequest({
        title: parsed.title,
        description: parsed.description,
        category,
        difficulty,
        points,
        emoji: parsed.emoji,
        generatedForUserId: ctx.user.id,
      });

      return { id, title: parsed.title, description: parsed.description, category, difficulty, points, emoji: parsed.emoji };
    }),

  getActive: protectedProcedure.query(async ({ ctx }) => {
    return getActiveSidequestForUser(ctx.user.id);
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getSidequestById(input.id);
    }),

  skip: protectedProcedure.mutation(async ({ ctx }) => {
    const active = await getActiveSidequestForUser(ctx.user.id);
    if (active) await deactivateSidequest(active.id);
    return { success: true };
  }),

  accept: protectedProcedure
    .input(z.object({ sidequestId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const sidequest = await getSidequestById(input.sidequestId);
      if (!sidequest) throw new TRPCError({ code: "NOT_FOUND", message: "Sidequest not found" });
      if (sidequest.generatedForUserId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "This sidequest was not generated for you" });
      }
      await acceptSidequest(input.sidequestId);
      return { success: true };
    }),

  reject: protectedProcedure
    .input(z.object({ sidequestId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const sidequest = await getSidequestById(input.sidequestId);
      if (!sidequest) throw new TRPCError({ code: "NOT_FOUND", message: "Sidequest not found" });
      if (sidequest.generatedForUserId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "This sidequest was not generated for you" });
      }
      await rejectSidequest(input.sidequestId);
      return { success: true };
    }),

  getIncomplete: protectedProcedure.query(async ({ ctx }) => {
    return getIncompleteSidequests(ctx.user.id);
  }),
});

// ─── Completion Router ────────────────────────────────────────────────────────

const completionRouter = router({
  submit: protectedProcedure
    .input(
      z.object({
        sidequestId: z.number(),
        mediaFiles: z.array(
          z.object({
            mediaUrl: z.string(),
            mediaKey: z.string(),
            mimeType: z.string(),
            mediaType: z.enum(["photo", "video"]),
          })
        ).min(1).max(10),
        caption: z.string().max(280).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const sidequest = await getSidequestById(input.sidequestId);
      if (!sidequest) throw new TRPCError({ code: "NOT_FOUND", message: "Sidequest not found" });
      if (sidequest.generatedForUserId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "This sidequest was not generated for you" });
      }

      const alreadyDone = await hasUserCompletedSidequest(ctx.user.id, input.sidequestId);
      if (alreadyDone) throw new TRPCError({ code: "CONFLICT", message: "Already completed this sidequest" });

      // Files are already uploaded to S3 via /api/upload — just save references
      const primaryMedia = input.mediaFiles[0];
      const completionId = await saveCompletion({
        userId: ctx.user.id,
        sidequestId: input.sidequestId,
        photoUrl: primaryMedia.mediaUrl,
        photoKey: primaryMedia.mediaKey,
        caption: input.caption,
        pointsEarned: sidequest.points,
      });

      // Save all media file references
      await saveMediaFiles(
        completionId,
        input.mediaFiles.map((m, i) => ({
          completionId,
          mediaUrl: m.mediaUrl,
          mediaKey: m.mediaKey,
          mediaType: m.mediaType,
          mimeType: m.mimeType,
          order: i,
        }))
      );

      // Deactivate the sidequest and update user points
      await deactivateSidequest(input.sidequestId);
      await incrementUserPoints(ctx.user.id, sidequest.points);

      return { completionId, pointsEarned: sidequest.points, mediaCount: input.mediaFiles.length };
    }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getCompletionById(input.id);
    }),

  getRecent: publicProcedure
    .input(z.object({ limit: z.number().min(1).max(50).default(20) }))
    .query(async ({ input }) => {
      const completions = await getRecentCompletions(input.limit);
      // Enrich with all media files
      const completionIds = completions.map((c) => c.id);
      const allMedia = await getMediaFilesForCompletions(completionIds);
      const mediaMap = new Map<number, typeof allMedia>();
      for (const m of allMedia) {
        if (!mediaMap.has(m.completionId)) mediaMap.set(m.completionId, []);
        mediaMap.get(m.completionId)!.push(m);
      }
      return completions.map((c) => ({
        ...c,
        media: mediaMap.get(c.id) ?? [],
      }));
    }),

  getUserHistory: publicProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const completions = await getUserCompletions(input.userId);
      const completionIds = completions.map((c) => c.id);
      const allMedia = await getMediaFilesForCompletions(completionIds);
      const mediaMap = new Map<number, typeof allMedia>();
      for (const m of allMedia) {
        if (!mediaMap.has(m.completionId)) mediaMap.set(m.completionId, []);
        mediaMap.get(m.completionId)!.push(m);
      }
      return completions.map((c) => ({
        ...c,
        media: mediaMap.get(c.id) ?? [],
      }));
    }),

  getMyHistory: protectedProcedure.query(async ({ ctx }) => {
    const completions = await getUserCompletions(ctx.user.id);
    const completionIds = completions.map((c) => c.id);
    const allMedia = await getMediaFilesForCompletions(completionIds);
    const mediaMap = new Map<number, typeof allMedia>();
    for (const m of allMedia) {
      if (!mediaMap.has(m.completionId)) mediaMap.set(m.completionId, []);
      mediaMap.get(m.completionId)!.push(m);
    }
    return completions.map((c) => ({
      ...c,
      media: mediaMap.get(c.id) ?? [],
    }));
  }),

  getCompletionMedia: publicProcedure
    .input(z.object({ completionId: z.number() }))
    .query(async ({ input }) => {
      return getMediaFilesForCompletion(input.completionId);
    }),
});

// ─── Leaderboard Router ──────────────────────────────────────────────────────

const leaderboardRouter = router({
  global: publicProcedure
    .input(z.object({ limit: z.number().min(1).max(100).default(50) }))
    .query(async ({ input }) => {
      return getGlobalLeaderboard(input.limit);
    }),

  friends: protectedProcedure.query(async ({ ctx }) => {
    return getFriendsLeaderboard(ctx.user.id);
  }),
});

// ─── Friends Router ──────────────────────────────────────────────────────────

const friendsRouter = router({
  sendRequest: protectedProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (input.userId === ctx.user.id) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Cannot friend yourself" });
      }
      const id = await sendFriendRequest(ctx.user.id, input.userId);
      return { id };
    }),

  respondRequest: protectedProcedure
    .input(z.object({ friendshipId: z.number(), status: z.enum(["accepted", "declined"]) }))
    .mutation(async ({ ctx, input }) => {
      await respondToFriendRequest(input.friendshipId, input.status);
      return { success: true };
    }),

  getPending: protectedProcedure.query(async ({ ctx }) => {
    return getPendingFriendRequests(ctx.user.id);
  }),

  list: protectedProcedure.query(async ({ ctx }) => {
    return getUserFriends(ctx.user.id);
  }),

  getStatus: protectedProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ ctx, input }) => {
      return getFriendshipStatus(ctx.user.id, input.userId);
    }),
});

// ─── User Router ─────────────────────────────────────────────────────────────

const userRouter = router({
  search: protectedProcedure
    .input(z.object({ query: z.string().min(1).max(50) }))
    .query(async ({ ctx, input }) => {
      return searchUsers(input.query, ctx.user.id);
    }),

  getProfile: publicProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      return getUserById(input.userId);
    }),

  getMe: protectedProcedure.query(async ({ ctx }) => {
    return getUserById(ctx.user.id);
  }),

  updateProfile: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(50).optional(),
        bio: z.string().max(200).optional(),
        avatarUrl: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await updateUserProfile(ctx.user.id, input);
      return { success: true };
    }),
});

// ─── Main App Router ─────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  sidequest: sidequestRouter,
  completion: completionRouter,
  leaderboard: leaderboardRouter,
  friends: friendsRouter,
  user: userRouter,
});

export type AppRouter = typeof appRouter;
