import { describe, expect, it, vi } from "vitest";

// Mock db module
const mockDb = {
  getActiveSidequestForUser: vi.fn(),
  getSidequestById: vi.fn(),
  acceptSidequest: vi.fn(),
  rejectSidequest: vi.fn(),
  getIncompleteSidequests: vi.fn(),
  deactivateSidequest: vi.fn(),
  saveSidequest: vi.fn(),
  saveCompletion: vi.fn(),
  saveMediaFiles: vi.fn(),
  hasUserCompletedSidequest: vi.fn(),
  incrementUserPoints: vi.fn(),
  getCompletionById: vi.fn(),
  getUserCompletions: vi.fn(),
  getGlobalLeaderboard: vi.fn(),
  getFriendsLeaderboard: vi.fn(),
  getRecentCompletions: vi.fn(),
  getUserById: vi.fn(),
  searchUsers: vi.fn(),
  sendFriendRequest: vi.fn(),
  respondToFriendRequest: vi.fn(),
  getPendingFriendRequests: vi.fn(),
  getUserFriends: vi.fn(),
  getFriendshipStatus: vi.fn(),
};

vi.mock("./db", () => mockDb);
vi.mock("./_core/llm", () => ({ invokeLLM: vi.fn() }));
vi.mock("./storage", () => ({ storagePut: vi.fn() }));

import type { TrpcContext } from "./_core/context";

function createTestContext(userId: number = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: `test-user-${userId}`,
      email: `user${userId}@test.com`,
      name: `Test User ${userId}`,
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("Accept/Reject/Incomplete Quest Flow", () => {
  it("getActive returns null when no active quest exists", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    mockDb.getActiveSidequestForUser.mockResolvedValue(null);

    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.getActive();

    expect(result).toBeNull();
    expect(mockDb.getActiveSidequestForUser).toHaveBeenCalledWith(1);
  });

  it("getActive returns a quest when one exists", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    const quest = {
      id: 1,
      title: "Test Quest",
      description: "Do something fun",
      category: "social",
      difficulty: "easy",
      points: 10,
      emoji: "🎯",
      generatedForUserId: 1,
      acceptedAt: null,
      rejectedAt: null,
      createdAt: new Date(),
    };
    mockDb.getActiveSidequestForUser.mockResolvedValue(quest);

    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.getActive();

    expect(result).toEqual(quest);
  });

  it("accept marks a quest as accepted", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    const quest = {
      id: 5,
      title: "Test Quest",
      generatedForUserId: 1,
    };
    mockDb.getSidequestById.mockResolvedValue(quest);
    mockDb.acceptSidequest.mockResolvedValue(undefined);

    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.accept({ sidequestId: 5 });

    expect(result).toEqual({ success: true });
    expect(mockDb.acceptSidequest).toHaveBeenCalledWith(5);
  });

  it("accept rejects if quest not found", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    mockDb.getSidequestById.mockResolvedValue(null);

    const caller = appRouter.createCaller(ctx);
    await expect(caller.sidequest.accept({ sidequestId: 999 })).rejects.toThrow("Sidequest not found");
  });

  it("accept rejects if quest belongs to another user", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext(1);
    mockDb.getSidequestById.mockResolvedValue({
      id: 5,
      generatedForUserId: 2,
    });

    const caller = appRouter.createCaller(ctx);
    await expect(caller.sidequest.accept({ sidequestId: 5 })).rejects.toThrow();
  });

  it("reject marks a quest as rejected", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    const quest = {
      id: 7,
      title: "Test Quest",
      generatedForUserId: 1,
    };
    mockDb.getSidequestById.mockResolvedValue(quest);
    mockDb.rejectSidequest.mockResolvedValue(undefined);

    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.reject({ sidequestId: 7 });

    expect(result).toEqual({ success: true });
    expect(mockDb.rejectSidequest).toHaveBeenCalledWith(7);
  });

  it("reject rejects if quest not found", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    mockDb.getSidequestById.mockResolvedValue(null);

    const caller = appRouter.createCaller(ctx);
    await expect(caller.sidequest.reject({ sidequestId: 999 })).rejects.toThrow("Sidequest not found");
  });

  it("getIncomplete returns list of incomplete quests", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    const quests = [
      { id: 1, title: "Quest 1", acceptedAt: new Date() },
      { id: 2, title: "Quest 2", acceptedAt: new Date() },
    ];
    mockDb.getIncompleteSidequests.mockResolvedValue(quests);

    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.getIncomplete();

    expect(result).toEqual(quests);
    expect(result).toHaveLength(2);
    expect(mockDb.getIncompleteSidequests).toHaveBeenCalledWith(1);
  });

  it("getIncomplete returns empty array when no quests", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    mockDb.getIncompleteSidequests.mockResolvedValue([]);

    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.getIncomplete();

    expect(result).toEqual([]);
  });

  it("skip deactivates the active quest", async () => {
    const { appRouter } = await import("./routers");
    const ctx = createTestContext();
    mockDb.getActiveSidequestForUser.mockResolvedValue({ id: 10 });
    mockDb.deactivateSidequest.mockResolvedValue(undefined);

    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.skip();

    expect(result).toEqual({ success: true });
    expect(mockDb.deactivateSidequest).toHaveBeenCalledWith(10);
  });
});
