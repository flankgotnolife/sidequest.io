import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { SIDEQUEST_CATEGORIES } from "../drizzle/schema";

// ─── Mock dependencies ────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  getActiveSidequestForUser: vi.fn().mockResolvedValue(null),
  deactivateSidequest: vi.fn().mockResolvedValue(undefined),
  saveSidequest: vi.fn().mockResolvedValue(42),
  getSidequestById: vi.fn().mockResolvedValue(undefined),
  hasUserCompletedSidequest: vi.fn().mockResolvedValue(false),
  saveCompletion: vi.fn().mockResolvedValue(1),
  incrementUserPoints: vi.fn().mockResolvedValue(undefined),
  getGlobalLeaderboard: vi.fn().mockResolvedValue([]),
  getFriendsLeaderboard: vi.fn().mockResolvedValue([]),
  getUserCompletions: vi.fn().mockResolvedValue([]),
  getRecentCompletions: vi.fn().mockResolvedValue([]),
  getCompletionById: vi.fn().mockResolvedValue(undefined),
  sendFriendRequest: vi.fn().mockResolvedValue(1),
  respondToFriendRequest: vi.fn().mockResolvedValue(undefined),
  getPendingFriendRequests: vi.fn().mockResolvedValue([]),
  getFriends: vi.fn().mockResolvedValue([]),
  getFriendshipStatus: vi.fn().mockResolvedValue(null),
  searchUsers: vi.fn().mockResolvedValue([]),
  getUserById: vi.fn().mockResolvedValue(undefined),
  upsertUser: vi.fn().mockResolvedValue(undefined),
  getUserByOpenId: vi.fn().mockResolvedValue(undefined),
  getUserPastQuestTitles: vi.fn().mockResolvedValue([]),
  saveMediaFiles: vi.fn().mockResolvedValue(undefined),
  getIncompleteSidequests: vi.fn().mockResolvedValue([]),
  acceptSidequest: vi.fn().mockResolvedValue(undefined),
  rejectSidequest: vi.fn().mockResolvedValue(undefined),
  getUserFriends: vi.fn().mockResolvedValue([]),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{
      message: {
        content: JSON.stringify({
          title: "Test Quest",
          description: "Do something fun and take a photo!",
          emoji: "🎯",
        }),
      },
    }],
  }),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://example.com/photo.jpg", key: "test-key" }),
}));

import * as dbModule from "./db";

// ─── Test Context ─────────────────────────────────────────────────────────────
type AuthUser = NonNullable<TrpcContext["user"]>;

function makeCtx(overrides?: Partial<AuthUser>): TrpcContext {
  const user: AuthUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    avatarUrl: null,
    totalPoints: 0,
    completedCount: 0,
    ...overrides,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("sidequest categories expansion", () => {
  it("includes all 17 categories", () => {
    expect(SIDEQUEST_CATEGORIES).toHaveLength(17);
    const expected = [
      "social",
      "creative",
      "physical",
      "food",
      "exploration",
      "random",
      "mindfulness",
      "tech",
      "weird",
      "dares",
      "photo",
      "skill",
      "community",
      "nature",
      "urban",
      "performance",
      "collectibles",
    ];
    expect(SIDEQUEST_CATEGORIES).toEqual(expected);
  });

  it("includes new fun categories", () => {
    const newCategories = ["weird", "dares", "photo", "skill", "community", "nature", "urban", "performance", "collectibles"];
    newCategories.forEach((cat) => {
      expect(SIDEQUEST_CATEGORIES).toContain(cat);
    });
  });
});

describe("sidequest.generate with new categories", () => {
  it("accepts weird category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "weird" });
    expect(result.category).toBe("weird");
    expect(result.title).toBe("Test Quest");
  });

  it("accepts dares category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "dares" });
    expect(result.category).toBe("dares");
  });

  it("accepts photo category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "photo" });
    expect(result.category).toBe("photo");
  });

  it("accepts skill category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "skill" });
    expect(result.category).toBe("skill");
  });

  it("accepts community category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "community" });
    expect(result.category).toBe("community");
  });

  it("accepts nature category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "nature" });
    expect(result.category).toBe("nature");
  });

  it("accepts urban category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "urban" });
    expect(result.category).toBe("urban");
  });

  it("accepts performance category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "performance" });
    expect(result.category).toBe("performance");
  });

  it("accepts collectibles category", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "collectibles" });
    expect(result.category).toBe("collectibles");
  });

  it("generates with all difficulty levels", async () => {
    const difficulties = ["easy", "medium", "hard", "legendary"] as const;
    for (const diff of difficulties) {
      const ctx = makeCtx();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.sidequest.generate({ difficulty: diff });
      expect(result.difficulty).toBe(diff);
    }
  });

  it("assigns correct points for each difficulty", async () => {
    const pointsMap = { easy: 10, medium: 25, hard: 50, legendary: 100 };
    for (const [diff, expectedPoints] of Object.entries(pointsMap)) {
      const ctx = makeCtx();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.sidequest.generate({ difficulty: diff as any });
      expect(result.points).toBe(expectedPoints);
    }
  });

  it("generates quests with all category and difficulty combinations", async () => {
    const sampleCategories = ["weird", "dares", "photo"];
    const sampleDifficulties = ["easy", "hard"];
    for (const cat of sampleCategories) {
      for (const diff of sampleDifficulties) {
        const ctx = makeCtx();
        const caller = appRouter.createCaller(ctx);
        const result = await caller.sidequest.generate({ category: cat as any, difficulty: diff as any });
        expect(result.category).toBe(cat);
        expect(result.difficulty).toBe(diff);
      }
    }
  });
});
