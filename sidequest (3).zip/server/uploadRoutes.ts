import { Express, Request, Response } from "express";
import multer from "multer";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";
import { sdk } from "./_core/sdk";

// Configure multer for memory storage with 500MB limit
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB max per file
    files: 10, // max 10 files per upload
  },
  fileFilter: (_req, file, cb) => {
    // Accept images and videos
    const allowedMimes = [
      // Images
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
      "image/heic",
      "image/heif",
      // Videos - standard
      "video/mp4",
      "video/webm",
      "video/quicktime", // .mov
      "video/x-msvideo", // .avi
      "video/x-matroska", // .mkv
      // Videos - 4K codecs
      "video/x-m4v",
      "video/3gpp",
      "video/3gpp2",
      "video/ogg",
      "video/mpeg",
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported file type: ${file.mimetype}`));
    }
  },
});

export function registerUploadRoutes(app: Express) {
  // POST /api/upload - Upload multiple files directly to S3
  app.post(
    "/api/upload",
    upload.array("files", 10),
    async (req: Request, res: Response) => {
      try {
        // Verify user is authenticated
        let user;
        try {
          user = await sdk.authenticateRequest(req);
        } catch {
          res.status(401).json({ error: "Unauthorized" });
          return;
        }

        const files = req.files as Express.Multer.File[];
        if (!files || files.length === 0) {
          res.status(400).json({ error: "No files provided" });
          return;
        }

        // Upload each file to S3
        const uploadedFiles = [];
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          const ext = file.originalname.split(".").pop() || getExtFromMime(file.mimetype);
          const fileKey = `completions/${user.id}-${nanoid(12)}.${ext}`;

          const { url } = await storagePut(fileKey, file.buffer, file.mimetype);

          const isVideo = file.mimetype.startsWith("video/");
          uploadedFiles.push({
            mediaUrl: url,
            mediaKey: fileKey,
            mediaType: isVideo ? "video" : "photo",
            mimeType: file.mimetype,
            originalName: file.originalname,
            size: file.size,
            order: i,
          });
        }

        res.json({
          success: true,
          files: uploadedFiles,
          totalSize: files.reduce((sum, f) => sum + f.size, 0),
        });
      } catch (error: any) {
        console.error("[Upload] Error:", error);
        if (error.code === "LIMIT_FILE_SIZE") {
          res.status(413).json({ error: "File too large. Maximum size is 500MB per file." });
        } else if (error.code === "LIMIT_FILE_COUNT") {
          res.status(400).json({ error: "Too many files. Maximum is 10 files per upload." });
        } else {
          res.status(500).json({ error: error.message || "Upload failed" });
        }
      }
    }
  );

  // Multer error handler
  app.use((err: any, _req: Request, res: Response, next: any) => {
    if (err instanceof multer.MulterError) {
      if (err.code === "LIMIT_FILE_SIZE") {
        res.status(413).json({ error: "File too large. Maximum size is 500MB per file." });
        return;
      }
      if (err.code === "LIMIT_FILE_COUNT") {
        res.status(400).json({ error: "Too many files. Maximum is 10 files per upload." });
        return;
      }
      res.status(400).json({ error: err.message });
      return;
    }
    next(err);
  });
}

function getExtFromMime(mime: string): string {
  const map: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/gif": "gif",
    "image/webp": "webp",
    "image/heic": "heic",
    "image/heif": "heif",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/quicktime": "mov",
    "video/x-msvideo": "avi",
    "video/x-matroska": "mkv",
    "video/x-m4v": "m4v",
    "video/3gpp": "3gp",
    "video/3gpp2": "3g2",
    "video/ogg": "ogv",
    "video/mpeg": "mpeg",
  };
  return map[mime] || "bin";
}
