import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Hoist mocks ─────────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  getActiveSidequestForUser: vi.fn().mockResolvedValue(null),
  deactivateSidequest: vi.fn().mockResolvedValue(undefined),
  saveSidequest: vi.fn().mockResolvedValue(42),
  getSidequestById: vi.fn().mockResolvedValue(undefined),
  hasUserCompletedSidequest: vi.fn().mockResolvedValue(false),
  saveCompletion: vi.fn().mockResolvedValue(1),
  saveMediaFiles: vi.fn().mockResolvedValue(undefined),
  incrementUserPoints: vi.fn().mockResolvedValue(undefined),
  getGlobalLeaderboard: vi.fn().mockResolvedValue([]),
  getFriendsLeaderboard: vi.fn().mockResolvedValue([]),
  getUserCompletions: vi.fn().mockResolvedValue([]),
  getRecentCompletions: vi.fn().mockResolvedValue([]),
  getCompletionById: vi.fn().mockResolvedValue(undefined),
  sendFriendRequest: vi.fn().mockResolvedValue(1),
  respondToFriendRequest: vi.fn().mockResolvedValue(undefined),
  getPendingFriendRequests: vi.fn().mockResolvedValue([]),
  getFriends: vi.fn().mockResolvedValue([]),
  getFriendshipStatus: vi.fn().mockResolvedValue(null),
  searchUsers: vi.fn().mockResolvedValue([]),
  getUserById: vi.fn().mockResolvedValue(undefined),
  upsertUser: vi.fn().mockResolvedValue(undefined),
  getUserByOpenId: vi.fn().mockResolvedValue(undefined),
  getUserPastQuestTitles: vi.fn().mockResolvedValue([]),
  getIncompleteSidequests: vi.fn().mockResolvedValue([]),
  acceptSidequest: vi.fn().mockResolvedValue(undefined),
  rejectSidequest: vi.fn().mockResolvedValue(undefined),
  getUserFriends: vi.fn().mockResolvedValue([]),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{
      message: {
        content: JSON.stringify({
          title: "Test Quest",
          description: "Do something fun and take a photo!",
          emoji: "🎯",
        }),
      },
    }],
  }),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://example.com/photo.jpg", key: "test-key" }),
}));

// ─── Import mocked modules ────────────────────────────────────────────────────
import * as dbModule from "./db";
import * as storageModule from "./storage";

// ─── Test Context ─────────────────────────────────────────────────────────────
type AuthUser = NonNullable<TrpcContext["user"]>;

function makeCtx(overrides?: Partial<AuthUser>): TrpcContext {
  const user: AuthUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    avatarUrl: null,
    totalPoints: 0,
    completedCount: 0,
    ...overrides,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function makePublicCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const ctx = makeCtx();
    const clearedCookies: any[] = [];
    (ctx.res as any).clearCookie = (name: string, opts: any) => clearedCookies.push({ name, opts });
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(clearedCookies).toHaveLength(1);
  });
});

describe("sidequest.generate", () => {
  beforeEach(() => {
    vi.mocked(dbModule.getActiveSidequestForUser).mockResolvedValue(null);
    vi.mocked(dbModule.saveSidequest).mockResolvedValue(42);
  });

  it("generates a sidequest for authenticated user", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ category: "social", difficulty: "easy" });
    expect(result.title).toBe("Test Quest");
    expect(result.points).toBe(10);
    expect(result.category).toBe("social");
    expect(result.difficulty).toBe("easy");
  });

  it("assigns correct points for hard difficulty", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ difficulty: "hard" });
    expect(result.points).toBe(50);
  });

  it("assigns correct points for legendary difficulty", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.generate({ difficulty: "legendary" });
    expect(result.points).toBe(100);
  });

  it("deactivates existing active quest before generating new one", async () => {
    vi.mocked(dbModule.getActiveSidequestForUser).mockResolvedValue({ id: 99, title: "Old Quest" } as any);
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await caller.sidequest.generate({});
    expect(dbModule.deactivateSidequest).toHaveBeenCalledWith(99);
  });

  it("throws UNAUTHORIZED if user is not logged in", async () => {
    const ctx = makePublicCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.sidequest.generate({})).rejects.toThrow();
  });
});

describe("sidequest.skip", () => {
  it("deactivates active quest", async () => {
    vi.mocked(dbModule.getActiveSidequestForUser).mockResolvedValue({ id: 55 } as any);
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.sidequest.skip();
    expect(result.success).toBe(true);
    expect(dbModule.deactivateSidequest).toHaveBeenCalledWith(55);
  });
});

const testMediaFile = {
  mediaUrl: "https://s3.example.com/completions/test.jpg",
  mediaKey: "completions/test.jpg",
  mimeType: "image/jpeg",
  mediaType: "photo" as const,
};

describe("completion.submit", () => {
  it("submits photo proof and awards points", async () => {
    vi.mocked(dbModule.getSidequestById).mockResolvedValue({
      id: 1,
      title: "Test Quest",
      points: 25,
      generatedForUserId: 1,
      difficulty: "medium",
    } as any);
    vi.mocked(dbModule.hasUserCompletedSidequest).mockResolvedValue(false);
    vi.mocked(dbModule.saveCompletion).mockResolvedValue(1);
    const ctx = makeCtx({ id: 1 });
    const caller = appRouter.createCaller(ctx);
    const result = await caller.completion.submit({
      sidequestId: 1,
      mediaFiles: [testMediaFile],
      caption: "I did it!",
    });
    expect(result.pointsEarned).toBe(25);
    expect(result.mediaCount).toBe(1);
    expect(dbModule.incrementUserPoints).toHaveBeenCalledWith(1, 25);
    expect(dbModule.saveMediaFiles).toHaveBeenCalled();
  });

  it("supports multiple media files", async () => {
    vi.mocked(dbModule.getSidequestById).mockResolvedValue({
      id: 1, title: "Test", points: 50, generatedForUserId: 1, difficulty: "hard",
    } as any);
    vi.mocked(dbModule.hasUserCompletedSidequest).mockResolvedValue(false);
    vi.mocked(dbModule.saveCompletion).mockResolvedValue(1);
    const ctx = makeCtx({ id: 1 });
    const caller = appRouter.createCaller(ctx);
    const result = await caller.completion.submit({
      sidequestId: 1,
      mediaFiles: [
        testMediaFile,
        { mediaUrl: "https://s3.example.com/vid.mp4", mediaKey: "completions/vid.mp4", mimeType: "video/mp4", mediaType: "video" },
      ],
    });
    expect(result.mediaCount).toBe(2);
  });

  it("throws NOT_FOUND if sidequest does not exist", async () => {
    vi.mocked(dbModule.getSidequestById).mockResolvedValue(undefined);
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.completion.submit({ sidequestId: 999, mediaFiles: [testMediaFile] })
    ).rejects.toThrow("Sidequest not found");
  });

  it("throws FORBIDDEN if sidequest belongs to another user", async () => {
    vi.mocked(dbModule.getSidequestById).mockResolvedValue({ id: 1, points: 10, generatedForUserId: 99 } as any);
    const ctx = makeCtx({ id: 1 });
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.completion.submit({ sidequestId: 1, mediaFiles: [testMediaFile] })
    ).rejects.toThrow("This sidequest was not generated for you");
  });

  it("throws CONFLICT if already completed", async () => {
    vi.mocked(dbModule.getSidequestById).mockResolvedValue({ id: 1, points: 10, generatedForUserId: 1 } as any);
    vi.mocked(dbModule.hasUserCompletedSidequest).mockResolvedValue(true);
    const ctx = makeCtx({ id: 1 });
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.completion.submit({ sidequestId: 1, mediaFiles: [testMediaFile] })
    ).rejects.toThrow("Already completed this sidequest");
  });
});

describe("leaderboard.global", () => {
  it("returns global leaderboard", async () => {
    vi.mocked(dbModule.getGlobalLeaderboard).mockResolvedValue([
      { id: 1, name: "Alice", totalPoints: 100, completedCount: 4, avatarUrl: null },
      { id: 2, name: "Bob", totalPoints: 50, completedCount: 2, avatarUrl: null },
    ] as any);
    const ctx = makePublicCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.leaderboard.global({ limit: 50 });
    expect(result).toHaveLength(2);
    expect(result[0]?.name).toBe("Alice");
  });
});

describe("friends.sendRequest", () => {
  it("sends a friend request", async () => {
    vi.mocked(dbModule.sendFriendRequest).mockResolvedValue(1 as any);
    const ctx = makeCtx({ id: 1 });
    const caller = appRouter.createCaller(ctx);
    const result = await caller.friends.sendRequest({ userId: 2 });
    expect(result.id).toBe(1);
  });

  it("throws BAD_REQUEST if friending yourself", async () => {
    const ctx = makeCtx({ id: 1 });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.friends.sendRequest({ userId: 1 })).rejects.toThrow("Cannot friend yourself");
  });
});
