import { describe, expect, it } from "vitest";
import * as fs from "fs";
import * as path from "path";

describe("PWA Configuration", () => {
  it("manifest.json exists and has required fields", () => {
    const manifestPath = path.resolve(__dirname, "../client/public/manifest.json");
    expect(fs.existsSync(manifestPath)).toBe(true);

    const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
    expect(manifest.name).toBeTruthy();
    expect(manifest.short_name).toBeTruthy();
    expect(manifest.start_url).toBe("/");
    expect(manifest.display).toBe("standalone");
    expect(manifest.background_color).toBeTruthy();
    expect(manifest.theme_color).toBeTruthy();
    expect(manifest.icons).toBeDefined();
    expect(manifest.icons.length).toBeGreaterThanOrEqual(2);
  });

  it("manifest has icons with required sizes (192x192 and 512x512)", () => {
    const manifestPath = path.resolve(__dirname, "../client/public/manifest.json");
    const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));

    const sizes = manifest.icons.map((icon: any) => icon.sizes);
    expect(sizes).toContain("192x192");
    expect(sizes).toContain("512x512");
  });

  it("manifest has a maskable icon", () => {
    const manifestPath = path.resolve(__dirname, "../client/public/manifest.json");
    const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));

    const maskableIcons = manifest.icons.filter((icon: any) => icon.purpose === "maskable");
    expect(maskableIcons.length).toBeGreaterThanOrEqual(1);
  });

  it("service worker file exists", () => {
    const swPath = path.resolve(__dirname, "../client/public/sw.js");
    expect(fs.existsSync(swPath)).toBe(true);

    const swContent = fs.readFileSync(swPath, "utf-8");
    expect(swContent).toContain("install");
    expect(swContent).toContain("activate");
    expect(swContent).toContain("fetch");
    expect(swContent).toContain("CACHE_NAME");
  });

  it("service worker does not precache cross-origin URLs", () => {
    const swPath = path.resolve(__dirname, "../client/public/sw.js");
    const swContent = fs.readFileSync(swPath, "utf-8");

    // Extract the PRECACHE_ASSETS array content
    const precacheMatch = swContent.match(/PRECACHE_ASSETS\s*=\s*\[([\s\S]*?)\]/);
    expect(precacheMatch).toBeTruthy();

    const precacheContent = precacheMatch![1];
    // Should not contain any https:// URLs in precache
    expect(precacheContent).not.toContain("https://");
  });

  it("offline fallback page exists", () => {
    const offlinePath = path.resolve(__dirname, "../client/public/offline.html");
    expect(fs.existsSync(offlinePath)).toBe(true);

    const offlineContent = fs.readFileSync(offlinePath, "utf-8");
    expect(offlineContent).toContain("SideQuest");
    expect(offlineContent).toContain("Offline");
  });

  it("index.html has PWA meta tags", () => {
    const indexPath = path.resolve(__dirname, "../client/index.html");
    const indexContent = fs.readFileSync(indexPath, "utf-8");

    expect(indexContent).toContain('rel="manifest"');
    expect(indexContent).toContain("apple-mobile-web-app-capable");
    expect(indexContent).toContain("apple-mobile-web-app-status-bar-style");
    expect(indexContent).toContain("apple-touch-icon");
    expect(indexContent).toContain('name="theme-color"');
  });

  it("main.tsx registers the service worker", () => {
    const mainPath = path.resolve(__dirname, "../client/src/main.tsx");
    const mainContent = fs.readFileSync(mainPath, "utf-8");

    expect(mainContent).toContain("serviceWorker");
    expect(mainContent).toContain("register");
    expect(mainContent).toContain("/sw.js");
  });

  it("InstallPrompt component exists", () => {
    const promptPath = path.resolve(__dirname, "../client/src/components/InstallPrompt.tsx");
    expect(fs.existsSync(promptPath)).toBe(true);

    const promptContent = fs.readFileSync(promptPath, "utf-8");
    expect(promptContent).toContain("beforeinstallprompt");
    expect(promptContent).toContain("Add to Home Screen");
    expect(promptContent).toContain("iOS");
  });
});
