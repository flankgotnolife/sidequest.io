import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock DB helpers ────────────────────────────────────────────────────────

vi.mock("./db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./db")>();
  return {
    ...actual,
    updateUserProfile: vi.fn().mockResolvedValue(undefined),
    getUserById: vi.fn().mockResolvedValue({
      id: 1,
      openId: "test-user",
      name: "Test User",
      email: "test@example.com",
      bio: "Hello world",
      avatarUrl: null,
      totalPoints: 100,
      completedCount: 5,
      role: "user",
      createdAt: new Date("2026-01-01"),
      updatedAt: new Date("2026-01-01"),
      lastSignedIn: new Date("2026-04-01"),
    }),
    getMediaFilesForCompletion: vi.fn().mockResolvedValue([
      {
        id: 1,
        completionId: 10,
        mediaUrl: "https://cdn.example.com/photo1.jpg",
        mediaKey: "photo1.jpg",
        mimeType: "image/jpeg",
        mediaType: "photo",
        order: 0,
        createdAt: new Date(),
      },
      {
        id: 2,
        completionId: 10,
        mediaUrl: "https://cdn.example.com/video1.mp4",
        mediaKey: "video1.mp4",
        mimeType: "video/mp4",
        mediaType: "video",
        order: 1,
        createdAt: new Date(),
      },
    ]),
    getRecentCompletions: vi.fn().mockResolvedValue([
      {
        id: 10,
        photoUrl: "https://cdn.example.com/photo1.jpg",
        caption: "Test caption",
        pointsEarned: 25,
        completedAt: new Date(),
        userId: 1,
        sidequestId: 1,
        title: "Test Quest",
        category: "creative",
        difficulty: "medium",
        emoji: "🎨",
        userName: "Test User",
        userAvatarUrl: null,
      },
    ]),
    getMediaFilesForCompletions: vi.fn().mockResolvedValue([
      {
        id: 1,
        completionId: 10,
        mediaUrl: "https://cdn.example.com/photo1.jpg",
        mediaKey: "photo1.jpg",
        mimeType: "image/jpeg",
        mediaType: "photo",
        order: 0,
        createdAt: new Date(),
      },
    ]),
    getUserCompletions: vi.fn().mockResolvedValue([
      {
        id: 10,
        photoUrl: "https://cdn.example.com/photo1.jpg",
        caption: "My quest",
        pointsEarned: 25,
        completedAt: new Date(),
        sidequestId: 1,
        title: "Test Quest",
        description: "Do something",
        category: "creative",
        difficulty: "medium",
        emoji: "🎨",
      },
    ]),
  };
});

// ─── Helpers ────────────────────────────────────────────────────────────────

function createAuthContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

// ─── Tests ──────────────────────────────────────────────────────────────────

describe("user.updateProfile", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("updates profile name and bio successfully", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.user.updateProfile({
      name: "New Name",
      bio: "My new bio",
    });

    expect(result).toEqual({ success: true });

    const { updateUserProfile } = await import("./db");
    expect(updateUserProfile).toHaveBeenCalledWith(1, {
      name: "New Name",
      bio: "My new bio",
    });
  });

  it("updates avatar URL only", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.user.updateProfile({
      avatarUrl: "https://cdn.example.com/avatar.jpg",
    });

    expect(result).toEqual({ success: true });

    const { updateUserProfile } = await import("./db");
    expect(updateUserProfile).toHaveBeenCalledWith(1, {
      avatarUrl: "https://cdn.example.com/avatar.jpg",
    });
  });

  it("rejects name longer than 50 characters", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.user.updateProfile({ name: "A".repeat(51) })
    ).rejects.toThrow();
  });

  it("rejects bio longer than 200 characters", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.user.updateProfile({ bio: "B".repeat(201) })
    ).rejects.toThrow();
  });

  it("rejects unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.user.updateProfile({ name: "Hacker" })
    ).rejects.toThrow();
  });
});

describe("user.getProfile", () => {
  it("returns user profile by ID", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const profile = await caller.user.getProfile({ userId: 1 });

    expect(profile).toBeDefined();
    expect(profile?.name).toBe("Test User");
    expect(profile?.bio).toBe("Hello world");
  });
});

describe("user.getMe", () => {
  it("returns current user profile", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const me = await caller.user.getMe();

    expect(me).toBeDefined();
    expect(me?.id).toBe(1);
    expect(me?.name).toBe("Test User");
  });
});

describe("completion.getCompletionMedia", () => {
  it("returns media files for a completion", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const media = await caller.completion.getCompletionMedia({ completionId: 10 });

    expect(media).toHaveLength(2);
    expect(media[0].mediaType).toBe("photo");
    expect(media[1].mediaType).toBe("video");
  });
});

describe("completion.getRecent", () => {
  it("returns recent completions enriched with media", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const feed = await caller.completion.getRecent({ limit: 20 });

    expect(feed).toHaveLength(1);
    expect(feed[0].title).toBe("Test Quest");
    expect(feed[0].media).toBeDefined();
    expect(Array.isArray(feed[0].media)).toBe(true);
    expect(feed[0].media.length).toBeGreaterThanOrEqual(0);
  });
});

describe("completion.getMyHistory", () => {
  it("returns authenticated user's completion history with media", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const history = await caller.completion.getMyHistory();

    expect(history).toHaveLength(1);
    expect(history[0].title).toBe("Test Quest");
    expect(history[0].media).toBeDefined();
    expect(Array.isArray(history[0].media)).toBe(true);
  });
});

describe("completion.getUserHistory", () => {
  it("returns another user's completion history with media", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const history = await caller.completion.getUserHistory({ userId: 1 });

    expect(history).toHaveLength(1);
    expect(history[0].title).toBe("Test Quest");
    expect(history[0].media).toBeDefined();
  });
});
