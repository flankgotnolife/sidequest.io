import { and, desc, eq, isNull, ne, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  completions,
  friendships,
  sidequests,
  users,
  mediaFiles,
  InsertMediaFile,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ──────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0] ?? undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0] ?? undefined;
}

export async function searchUsers(query: string, excludeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: users.id,
      name: users.name,
      totalPoints: users.totalPoints,
      completedCount: users.completedCount,
      avatarUrl: users.avatarUrl,
    })
    .from(users)
    .where(
      and(
        ne(users.id, excludeId),
        sql`LOWER(${users.name}) LIKE LOWER(${`%${query}%`})`
      )
    )
    .limit(20);
}

export async function updateUserProfile(userId: number, data: { name?: string; bio?: string; avatarUrl?: string }) {
  const db = await getDb();
  if (!db) return;
  const updateSet: Record<string, unknown> = {};
  if (data.name !== undefined) updateSet.name = data.name;
  if (data.bio !== undefined) updateSet.bio = data.bio;
  if (data.avatarUrl !== undefined) updateSet.avatarUrl = data.avatarUrl;
  if (Object.keys(updateSet).length === 0) return;
  await db.update(users).set(updateSet).where(eq(users.id, userId));
}

export async function getMediaFilesForCompletions(completionIds: number[]) {
  const db = await getDb();
  if (!db || completionIds.length === 0) return [];
  return db
    .select()
    .from(mediaFiles)
    .where(sql`${mediaFiles.completionId} IN (${sql.join(completionIds.map((id) => sql`${id}`), sql`, `)})`)
    .orderBy(mediaFiles.completionId, mediaFiles.order);
}

// ─── Sidequests ──────────────────────────────────────────────────────────────

export async function saveSidequest(data: {
  title: string;
  description: string;
  category: string;
  difficulty: "easy" | "medium" | "hard" | "legendary";
  points: number;
  emoji: string;
  generatedForUserId: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(sidequests).values(data);
  return result.insertId as number;
}

export async function getSidequestById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(sidequests).where(eq(sidequests.id, id)).limit(1);
  return result[0] ?? undefined;
}

/**
 * Get the most recent sidequest that is newly generated (not yet accepted or rejected).
 * Returns null (not undefined) so tRPC queries don't break.
 */
export async function getActiveSidequestForUser(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(sidequests)
    .where(
      and(
        eq(sidequests.generatedForUserId, userId),
        isNull(sidequests.acceptedAt),
        isNull(sidequests.rejectedAt)
      )
    )
    .orderBy(desc(sidequests.createdAt))
    .limit(1);
  return result[0] ?? null;
}

/**
 * Mark a sidequest as rejected (used when skipping or rejecting).
 */
export async function deactivateSidequest(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(sidequests).set({ rejectedAt: new Date() }).where(eq(sidequests.id, id));
}

/**
 * Accept a sidequest — sets acceptedAt timestamp.
 */
export async function acceptSidequest(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(sidequests).set({ acceptedAt: new Date() }).where(eq(sidequests.id, id));
}

/**
 * Reject a sidequest — sets rejectedAt timestamp.
 */
export async function rejectSidequest(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(sidequests).set({ rejectedAt: new Date() }).where(eq(sidequests.id, id));
}

/**
 * Get all accepted-but-not-completed sidequests for a user.
 */
export async function getIncompleteSidequests(userId: number) {
  const db = await getDb();
  if (!db) return [];

  // Get IDs of sidequests this user has already completed
  const completedIds = await db
    .select({ sidequestId: completions.sidequestId })
    .from(completions)
    .where(eq(completions.userId, userId));
  const completedSet = new Set(completedIds.map((c) => c.sidequestId));

  // Get accepted quests that are not rejected
  const results = await db
    .select({
      id: sidequests.id,
      title: sidequests.title,
      description: sidequests.description,
      category: sidequests.category,
      difficulty: sidequests.difficulty,
      points: sidequests.points,
      emoji: sidequests.emoji,
      acceptedAt: sidequests.acceptedAt,
      createdAt: sidequests.createdAt,
    })
    .from(sidequests)
    .where(
      and(
        eq(sidequests.generatedForUserId, userId),
        sql`${sidequests.acceptedAt} IS NOT NULL`,
        isNull(sidequests.rejectedAt)
      )
    )
    .orderBy(desc(sidequests.acceptedAt));

  // Filter out completed ones
  return results.filter((q) => !completedSet.has(q.id));
}

// ─── Completions ─────────────────────────────────────────────────────────────

export async function saveCompletion(data: {
  userId: number;
  sidequestId: number;
  photoUrl: string;
  photoKey: string;
  caption?: string;
  pointsEarned: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(completions).values(data);
  return result.insertId as number;
}

export async function getUserCompletions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: completions.id,
      photoUrl: completions.photoUrl,
      caption: completions.caption,
      pointsEarned: completions.pointsEarned,
      completedAt: completions.completedAt,
      sidequestId: completions.sidequestId,
      title: sidequests.title,
      description: sidequests.description,
      category: sidequests.category,
      difficulty: sidequests.difficulty,
      emoji: sidequests.emoji,
    })
    .from(completions)
    .innerJoin(sidequests, eq(completions.sidequestId, sidequests.id))
    .where(eq(completions.userId, userId))
    .orderBy(desc(completions.completedAt));
}

export async function getCompletionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({
      id: completions.id,
      photoUrl: completions.photoUrl,
      caption: completions.caption,
      pointsEarned: completions.pointsEarned,
      completedAt: completions.completedAt,
      userId: completions.userId,
      sidequestId: completions.sidequestId,
      title: sidequests.title,
      description: sidequests.description,
      category: sidequests.category,
      difficulty: sidequests.difficulty,
      emoji: sidequests.emoji,
      userName: users.name,
      userAvatarUrl: users.avatarUrl,
    })
    .from(completions)
    .innerJoin(sidequests, eq(completions.sidequestId, sidequests.id))
    .innerJoin(users, eq(completions.userId, users.id))
    .where(eq(completions.id, id))
    .limit(1);
  return result[0] ?? undefined;
}

export async function getRecentCompletions(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: completions.id,
      photoUrl: completions.photoUrl,
      caption: completions.caption,
      pointsEarned: completions.pointsEarned,
      completedAt: completions.completedAt,
      userId: completions.userId,
      sidequestId: completions.sidequestId,
      title: sidequests.title,
      category: sidequests.category,
      difficulty: sidequests.difficulty,
      emoji: sidequests.emoji,
      userName: users.name,
      userAvatarUrl: users.avatarUrl,
    })
    .from(completions)
    .innerJoin(sidequests, eq(completions.sidequestId, sidequests.id))
    .innerJoin(users, eq(completions.userId, users.id))
    .orderBy(desc(completions.completedAt))
    .limit(limit);
}

export async function hasUserCompletedSidequest(userId: number, sidequestId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select({ id: completions.id })
    .from(completions)
    .where(and(eq(completions.userId, userId), eq(completions.sidequestId, sidequestId)))
    .limit(1);
  return result.length > 0;
}

// ─── Leaderboard ─────────────────────────────────────────────────────────────

export async function getGlobalLeaderboard(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: users.id,
      name: users.name,
      avatarUrl: users.avatarUrl,
      totalPoints: users.totalPoints,
      completedCount: users.completedCount,
    })
    .from(users)
    .orderBy(desc(users.totalPoints))
    .limit(limit);
}

export async function getFriendsLeaderboard(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const friendIds = await db
    .select({
      friendId: sql<number>`CASE WHEN ${friendships.requesterId} = ${userId} THEN ${friendships.addresseeId} ELSE ${friendships.requesterId} END`,
    })
    .from(friendships)
    .where(
      and(
        eq(friendships.status, "accepted"),
        or(eq(friendships.requesterId, userId), eq(friendships.addresseeId, userId))
      )
    );

  const ids = [userId, ...friendIds.map((f) => f.friendId)];

  return db
    .select({
      id: users.id,
      name: users.name,
      avatarUrl: users.avatarUrl,
      totalPoints: users.totalPoints,
      completedCount: users.completedCount,
    })
    .from(users)
    .where(sql`${users.id} IN (${sql.join(ids.map((id) => sql`${id}`), sql`, `)})`)
    .orderBy(desc(users.totalPoints));
}

export async function incrementUserPoints(userId: number, points: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(users)
    .set({
      totalPoints: sql`${users.totalPoints} + ${points}`,
      completedCount: sql`${users.completedCount} + 1`,
    })
    .where(eq(users.id, userId));
}

// ─── Friendships ─────────────────────────────────────────────────────────────

export async function sendFriendRequest(requesterId: number, addresseeId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const existing = await db
    .select()
    .from(friendships)
    .where(
      or(
        and(eq(friendships.requesterId, requesterId), eq(friendships.addresseeId, addresseeId)),
        and(eq(friendships.requesterId, addresseeId), eq(friendships.addresseeId, requesterId))
      )
    )
    .limit(1);
  if (existing.length > 0) return existing[0];
  const [result] = await db.insert(friendships).values({ requesterId, addresseeId, status: "pending" });
  return result.insertId as number;
}

export async function respondToFriendRequest(
  friendshipId: number,
  status: "accepted" | "declined"
) {
  const db = await getDb();
  if (!db) return;
  await db.update(friendships).set({ status, updatedAt: new Date() }).where(eq(friendships.id, friendshipId));
}

export async function getPendingFriendRequests(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: friendships.id,
      requesterId: friendships.requesterId,
      requesterName: users.name,
      requesterAvatarUrl: users.avatarUrl,
      createdAt: friendships.createdAt,
    })
    .from(friendships)
    .innerJoin(users, eq(friendships.requesterId, users.id))
    .where(and(eq(friendships.addresseeId, userId), eq(friendships.status, "pending")));
}

export async function getUserFriends(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({
      friendshipId: friendships.id,
      requesterId: friendships.requesterId,
      addresseeId: friendships.addresseeId,
      friendId: sql<number>`CASE WHEN ${friendships.requesterId} = ${userId} THEN ${friendships.addresseeId} ELSE ${friendships.requesterId} END`,
      friendName: users.name,
      friendAvatarUrl: users.avatarUrl,
      friendTotalPoints: users.totalPoints,
      friendCompletedCount: users.completedCount,
    })
    .from(friendships)
    .innerJoin(
      users,
      sql`${users.id} = CASE WHEN ${friendships.requesterId} = ${userId} THEN ${friendships.addresseeId} ELSE ${friendships.requesterId} END`
    )
    .where(
      and(
        eq(friendships.status, "accepted"),
        or(eq(friendships.requesterId, userId), eq(friendships.addresseeId, userId))
      )
    );
  return rows;
}

export async function getFriendshipStatus(userId: number, otherId: number) {
  const db = await getDb();
  if (!db) return { status: "none" as const };
  const result = await db
    .select()
    .from(friendships)
    .where(
      or(
        and(eq(friendships.requesterId, userId), eq(friendships.addresseeId, otherId)),
        and(eq(friendships.requesterId, otherId), eq(friendships.addresseeId, userId))
      )
    )
    .limit(1);
  return { status: (result[0]?.status ?? "none") as "none" | "pending" | "accepted" | "declined" };
}

// ─── Media Files ─────────────────────────────────────────────────────────────

export async function saveMediaFiles(completionId: number, files: InsertMediaFile[]) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  if (files.length === 0) return;
  await db.insert(mediaFiles).values(files);
}

export async function getMediaFilesForCompletion(completionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(mediaFiles)
    .where(eq(mediaFiles.completionId, completionId))
    .orderBy(mediaFiles.order);
}

// ─── Quest History (for duplicate prevention) ────────────────────────────────

/**
 * Get all past quest titles generated for a user (for feeding to LLM to avoid repeats).
 * Returns the most recent 100 titles.
 */
export async function getUserPastQuestTitles(userId: number): Promise<string[]> {
  const db = await getDb();
  if (!db) return [];
  const results = await db
    .select({ title: sidequests.title })
    .from(sidequests)
    .where(eq(sidequests.generatedForUserId, userId))
    .orderBy(desc(sidequests.createdAt))
    .limit(100);
  return results.map((r) => r.title);
}
