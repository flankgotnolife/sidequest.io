CREATE TABLE `mediaFiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`completionId` int NOT NULL,
	`mediaUrl` text NOT NULL,
	`mediaKey` text NOT NULL,
	`mediaType` enum('photo','video') NOT NULL,
	`mimeType` varchar(64) NOT NULL,
	`order` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mediaFiles_id` PRIMARY KEY(`id`)
);
