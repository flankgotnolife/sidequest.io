ALTER TABLE `sidequests` ADD `acceptedAt` timestamp;--> statement-breakpoint
ALTER TABLE `sidequests` ADD `rejectedAt` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD `bio` text;--> statement-breakpoint
ALTER TABLE `sidequests` DROP COLUMN `isActive`;