ALTER TABLE `sidequests` ADD `acceptedAt` timestamp;--> statement-breakpoint
ALTER TABLE `sidequests` ADD `rejectedAt` timestamp;