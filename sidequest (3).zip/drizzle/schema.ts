import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  avatarUrl: text("avatarUrl"),
  bio: text("bio"),
  totalPoints: int("totalPoints").default(0).notNull(),
  completedCount: int("completedCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Sidequest categories
export const SIDEQUEST_CATEGORIES = [
  "social",
  "creative",
  "physical",
  "food",
  "exploration",
  "random",
  "mindfulness",
  "tech",
  "weird",
  "dares",
  "photo",
  "skill",
  "community",
  "nature",
  "urban",
  "performance",
  "collectibles",
] as const;

export type SidequestCategory = (typeof SIDEQUEST_CATEGORIES)[number];

// Difficulty levels
export const DIFFICULTY_LEVELS = ["easy", "medium", "hard", "legendary"] as const;
export type DifficultyLevel = (typeof DIFFICULTY_LEVELS)[number];

// Points per difficulty
export const DIFFICULTY_POINTS: Record<DifficultyLevel, number> = {
  easy: 10,
  medium: 25,
  hard: 50,
  legendary: 100,
};

// A sidequest template / generated challenge
export const sidequests = mysqlTable("sidequests", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard", "legendary"])
    .default("easy")
    .notNull(),
  points: int("points").default(10).notNull(),
  emoji: varchar("emoji", { length: 8 }).default("🎯").notNull(),
  generatedForUserId: int("generatedForUserId"),
  acceptedAt: timestamp("acceptedAt"),
  rejectedAt: timestamp("rejectedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Sidequest = typeof sidequests.$inferSelect;
export type InsertSidequest = typeof sidequests.$inferInsert;

// A user's completion of a sidequest (with photo proof)
export const completions = mysqlTable("completions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sidequestId: int("sidequestId").notNull(),
  photoUrl: text("photoUrl").notNull(),
  photoKey: text("photoKey").notNull(),
  caption: text("caption"),
  pointsEarned: int("pointsEarned").default(0).notNull(),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});

export type Completion = typeof completions.$inferSelect;
export type InsertCompletion = typeof completions.$inferInsert;

// Friend relationships
export const friendships = mysqlTable("friendships", {
  id: int("id").autoincrement().primaryKey(),
  requesterId: int("requesterId").notNull(),
  addresseeId: int("addresseeId").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "declined"])
    .default("pending")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Friendship = typeof friendships.$inferSelect;
export type InsertFriendship = typeof friendships.$inferInsert;

// Media files (photos/videos) for a completion
export const mediaFiles = mysqlTable("mediaFiles", {
  id: int("id").autoincrement().primaryKey(),
  completionId: int("completionId").notNull(),
  mediaUrl: text("mediaUrl").notNull(),
  mediaKey: text("mediaKey").notNull(),
  mediaType: mysqlEnum("mediaType", ["photo", "video"]).notNull(),
  mimeType: varchar("mimeType", { length: 64 }).notNull(),
  order: int("order").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MediaFile = typeof mediaFiles.$inferSelect;
export type InsertMediaFile = typeof mediaFiles.$inferInsert;
