ALTER TABLE `sidequests` DROP COLUMN `acceptedAt`;--> statement-breakpoint
ALTER TABLE `sidequests` DROP COLUMN `rejectedAt`;