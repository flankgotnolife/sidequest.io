# SideQuest TODO

## Database & Schema
- [x] Database schema: sidequests, completions, friends, user_points tables
- [x] Generate & apply DB migrations
- [x] Add mediaFiles table for multi-file uploads

## Backend
- [x] tRPC router: generate random sidequest (LLM-powered)
- [x] tRPC router: submit completion with photo upload to S3
- [x] tRPC router: leaderboard (global & friends)
- [x] tRPC router: friend system (send/accept/decline requests)
- [x] tRPC router: user profile & stats
- [x] tRPC router: sidequest history for a user
- [x] tRPC router: photo verification display (view proof submissions)
- [x] Points/scoring system (base points + difficulty multiplier)

## Frontend
- [x] Landing page with hand-drawn sketch aesthetic
- [x] Home/Dashboard: active sidequest card + generate new button
- [x] Sidequest detail page with photo upload proof submission
- [x] Leaderboard page (global + friends tabs)
- [x] Profile page (stats, history, completed sidequests)
- [x] Friends page (search users, send/accept requests, friend leaderboard)
- [x] Photo proof gallery / verification display

## Design
- [x] Global hand-drawn sketch CSS theme (cream paper bg, charcoal lines)
- [x] Caveat / Permanent Marker font for headers
- [x] Courier Prime / monospace font for body
- [x] Dashed borders, imperfect shapes, drafting marks decorations
- [x] Responsive mobile layout
- [x] Loading skeletons and empty states
- [x] Toast notifications for actions

## Expanded Categories
- [x] Add 9 new quest categories
- [x] Rewrite LLM prompt for hilarious challenges
- [x] Improve difficulty scaling

## Multi-File Upload
- [x] mediaFiles table for multiple photos/videos per completion
- [x] Backend support for multi-file uploads
- [x] Frontend multi-file upload with preview
- [x] Support video file types (mp4, webm, mov)

## Current Sprint - Accept/Reject, Complete Button, Bug Fixes
- [x] Add acceptedAt/rejectedAt columns to sidequests table (apply migration)
- [x] Update schema.ts to use acceptedAt/rejectedAt instead of isActive
- [x] Update db.ts: accept/reject/incomplete helpers using acceptedAt/rejectedAt
- [x] Update routers.ts: add accept, reject, getIncomplete procedures
- [x] Fix: getActive query returning undefined (must return null not undefined)
- [x] Add complete button to quest cards for easy completion
- [x] Fix: upload button click event bubbling (stopPropagation)
- [x] Fix: caption textarea click event bubbling
- [x] Rewrite Play.tsx with accept/reject flow, incomplete tab, and complete button
- [x] Write/update tests (37 passing)


## Unique Quest Generation
- [x] Add db helper to fetch all past quest titles for a user (getUserPastQuestTitles, last 100)
- [x] Feed past quest titles to LLM prompt so it never repeats
- [x] Improve LLM prompt for maximum variety and creativity
- [x] Add randomization elements (20 tones x 20 settings x 20 props = 8000 combos + random seed)
- [x] Test unique quest generation (47 tests passing)
- [x] Add server-side duplicate title check with retry after LLM response (up to 3 retries)
- [x] All 47 tests passing with duplicate prevention logic


## 4K 60fps Video Upload Support
- [x] Increase server body size limit to 500MB for large video uploads
- [x] Add multipart upload endpoint (/api/upload) with multer to bypass tRPC base64 limits
- [x] Upload files to S3 via storagePut from multer buffer
- [x] Update frontend: file size limit to 500MB, accept 4K video containers
- [x] Add upload progress bar with percentage and speed indicator (XHR)
- [x] Add video preview for uploaded videos
- [x] Accept 4K video containers (mp4, mov, webm, mkv, avi, quicktime) — codec support depends on browser playback
- [x] Update MIME type validation for video formats
- [x] Update completion.submit contract: mediaUrl/mediaKey instead of base64
- [x] Update tests for new contract (48 tests passing)


## Progressive Web App (PWA) - Installable on All Platforms
- [x] Create web app manifest (manifest.json) with app name, icons, theme colors, standalone display mode
- [x] Generate PWA app icons (512x512 + maskable) with hand-drawn crossed-swords theme
- [x] Create service worker for offline caching (network-first for pages, cache-first for assets)
- [x] Register service worker in main.tsx with hourly update checks
- [x] Add meta tags for iOS (apple-mobile-web-app-capable, status-bar-style, apple-touch-icon)
- [x] Add install prompt banner/button for desktop and Android (beforeinstallprompt)
- [x] Add iOS install instructions (Share > Add to Home Screen)
- [x] Add offline fallback page with sketch aesthetic
- [x] Service worker auto-copied via client/public/
- [x] All 57 tests passing (including 9 PWA configuration tests)


## In-App Camera Capture
- [x] Add camera capture component using MediaDevices API (getUserMedia)
- [x] Support photo capture with front/back camera toggle
- [x] Support video recording with start/stop controls
- [x] Integrate camera capture into the quest completion flow on Play page
- [x] Add camera permission handling and fallback to file picker

## Profile Editing
- [x] Add bio column to users table in database
- [x] Add tRPC procedure to update user profile (name, avatar, bio)
- [x] Add avatar upload via S3 (reuse upload endpoint)
- [x] Create profile edit page/modal with form fields
- [x] Display bio on user profile page

## View Others' Proof Submissions
- [x] Add tRPC procedure to get completions with media files for a specific user
- [x] Add tRPC procedure to get all recent completions with media (community feed)
- [x] Create media gallery component with lightbox for photos and video player
- [x] Add gallery to Profile page showing user's proof submissions
- [x] Add gallery to Feed page showing community proof submissions
- [x] Allow clicking on proof thumbnails to view full-size media
